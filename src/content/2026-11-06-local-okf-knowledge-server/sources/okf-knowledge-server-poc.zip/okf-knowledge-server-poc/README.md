# Local OKF Knowledge Server POC

This workspace evaluates `@mfdaves/okf-mcp` for corporate coding standards stored in independent Git repositories. It includes a stock upstream evaluation, a locked dependency-hardened reproduction, and a two-tool adapter built over the upstream index, search, and graph. The five Golden Sources are entirely synthetic.

**Decision:** NO-GO for production with upstream alone. CONDITIONAL GO for an isolated adapter pilot, subject to the [acceptance gates and prerequisites](docs/final-recommendation.md).

## Quick start

Install Git and Node.js 22 or later. From this directory run:

```sh
node scripts/bootstrap.mjs
npm test
npm run benchmark
npm run scale
npm run remote
```

Bootstrap installs the lockfile without lifecycle scripts and makes five independent local Git origins and shallow detached snapshots. The tests start real MCP subprocesses. Performance, retrieval, and remote commands write into `results/` and can replace the included samples. Remote tests need network access to GitHub's API and raw content. Maven and a supported Codex login are needed only for the optional agent trial.

```sh
npm run codex:register
npm run codex:trial
```

The first command edits the developer's Codex MCP configuration explicitly. The trial uses one-off configuration overrides and rejects a non-synthetic active snapshot. See [Codex integration](docs/codex-integration.md) before running the trial. For real GitHub sources, use [installation and synchronization](docs/installation.md).

## Evidence and decisions

| Deliverable | Path |
|---|---|
| Architecture decision report | [Final recommendation](docs/final-recommendation.md) |
| Design and trust boundary | [Architecture](docs/architecture.md) |
| Setup, Git, refresh, and troubleshooting | [Installation](docs/installation.md) |
| Codex registration, trial and rubric | [Codex integration](docs/codex-integration.md) |
| Security findings and mitigations | [Security assessment](docs/security-assessment.md) |
| Metrics and scale protocol | [Benchmark results](docs/benchmark-results.md) |
| Native capability matrix and weighted alternatives | [Gap analysis](docs/gap-analysis.md) |
| Frozen queries and judgments | [judgments.tsv](tests/retrieval/judgments.tsv) |
| Per-query payloads and scores | [benchmark.json](results/benchmark.json), [benchmark.csv](results/benchmark.csv) |
| SDK, Git and security results | [test-results.json](results/test-results.json) |
| Gate outcomes | [acceptance.json](results/acceptance.json) |
| Resource and latency samples | [scale.json](results/scale.json) |
| Reproduction transcript and upstream evidence | [Evidence index](results/evidence/README.md) |

The local Knowledge Server requires no hosted service, database, Docker, API key, or embedding model. An external coding model may receive tool output as part of agent inference. Follow your organization's model and data policies before loading real sources.
