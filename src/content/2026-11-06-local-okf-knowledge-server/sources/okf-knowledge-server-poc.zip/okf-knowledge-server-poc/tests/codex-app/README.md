# Orders service trial

Minimal Spring Boot starter application. The order creation endpoint is the first use case. The request should carry a product code and a quantity. An in-memory implementation is sufficient.
