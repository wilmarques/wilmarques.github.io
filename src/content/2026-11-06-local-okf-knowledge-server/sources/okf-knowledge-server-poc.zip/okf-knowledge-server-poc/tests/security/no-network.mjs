import net from 'node:net';
const blocked = () => {
  process.stderr.write('Unexpected network attempt\n');
  throw new Error('Unexpected network attempt');
};
globalThis.fetch = blocked;
net.Socket.prototype.connect = blocked;
