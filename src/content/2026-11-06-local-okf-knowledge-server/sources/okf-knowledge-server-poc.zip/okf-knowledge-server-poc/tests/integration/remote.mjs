import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { connect } from './client.mjs';
import { clockTicksPerSecond, processStats } from '../../scripts/process-stats.mjs';
import { root, upstreamBin } from '../../src/knowledge.mjs';

const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'okf-remote-poc-'));
const env = Object.fromEntries(Object.entries(process.env).filter(([key]) =>
  ['HTTP_PROXY','HTTPS_PROXY','NO_PROXY','http_proxy','https_proxy','no_proxy','NODE_USE_ENV_PROXY','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE'].includes(key)));
env.NODE_USE_ENV_PROXY ??= '1';
const remote = [
  { id: 'okf-runtime', path: 'https://github.com/mfdaves/okf-mcp/tree/d10a05528289cb4a3440e7ea3c4b567d351a44d6/okf/okf-mcp/runtime', query: 'MCP server' },
  { id: 'bitcoin-catalog', path: 'https://github.com/GoogleCloudPlatform/open-knowledge-format/tree/ad30107c31c06aec8a7d5636e0d1058118604e6f/bundles/crypto_bitcoin/datasets', query: 'Bitcoin crypto dataset' },
];
const args = entries => [upstreamBin, ...entries.flatMap(entry => ['--remote-bundle', `${entry.id}=${entry.path}`]), 'mcp'];
const output = {};
const validStart = performance.now();
let session;
try {
  session = await connect('native', { args: args(remote), env, timeout: 120_000, cwd });
  const bundles = await session.call('list_bundles');
  const tools = (await session.client.listTools()).tools.map(tool => tool.name);
  assert.equal(tools.includes('load_remote_bundle'), false);
  const results = [];
  for (const entry of remote) {
    const search = await session.call('search_concepts', { query: entry.query, limit: 5, detail: 'full' });
    const hit = search.results.find(item => item.bundle === entry.id);
    assert.ok(hit, `Missing result from ${entry.id}`);
    const doc = await session.call('get_concept', { uri: hit.uri });
    results.push({ query: entry.query, returned: search.results.map(row => row.uri),
      sample: { uri: doc.uri, bundle: doc.bundle, path: doc.path, bodyBytes: Buffer.byteLength(doc.body) } });
  }
  assert.equal(bundles.length, 2);
  assert.ok(bundles.every(bundle => bundle.remote && /^[a-f0-9]{40}$/.test(bundle.revision)));
  assert.deepEqual(fs.readdirSync(cwd), []);
  output.publicBundles = { status: 'PASS', startupMs: session.startupMs, resources: processStats(session.pid), cpuTicksPerSecond: clockTicksPerSecond(), bundles, results,
    noWorkingDirectoryFiles: true, disabledRuntimeRemoteTool: true, stderr: session.stderr() };
} catch (error) {
  output.publicBundles = { status: 'NOT VERIFIED', durationMs: performance.now()-validStart, error: error.message };
} finally { await session?.close(); }
const failedStart = performance.now();
let unexpected;
let stderr = '';
try {
  unexpected = await connect('native', { args: [upstreamBin, '--bundle', `fixture=${path.join(root, 'golden-sources/java-standards')}`, ...args([{ ...remote[0], path: remote[0].path + '/missing-poc-directory' }]).slice(1)],
    env, timeout: 40_000, cwd, onStderr: value => { stderr = value; } });
  output.unavailable = { status: 'FAIL', reason: 'An unavailable source allowed startup' };
} catch (error) {
  const evidence = stderr || error.message;
  output.unavailable = { status: /GitHub request failed: 404/.test(evidence) ? 'PASS' : 'PARTIAL',
    durationMs: performance.now()-failedStart, localBundleWasAlsoConfigured: true, error: evidence };
} finally {
  await unexpected?.close();
  fs.rmSync(cwd, { recursive: true, force: true });
}
fs.writeFileSync(path.join(root, 'results/evidence/remote.json'), JSON.stringify(output, null, 2)+'\n');
console.log(JSON.stringify(output, null, 2));
if (output.publicBundles.status !== 'PASS' || output.unavailable.status !== 'PASS') process.exitCode = 1;
