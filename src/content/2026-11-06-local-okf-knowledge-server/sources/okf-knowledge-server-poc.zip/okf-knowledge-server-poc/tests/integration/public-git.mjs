import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { root } from '../../src/knowledge.mjs';
import { synchronize } from '../../scripts/sync.mjs';

const destination = fs.mkdtempSync(path.join(os.tmpdir(), 'okf-public-git-'));
const ref = 'ad30107c31c06aec8a7d5636e0d1058118604e6f';
const source = { id: 'bitcoin-catalog', url: 'https://github.com/GoogleCloudPlatform/open-knowledge-format.git',
  ref, root: 'bundles/crypto_bitcoin', reviewers: ['human:unused-example'] };
const report = { source, privateCredentialsTested: false };
try {
  const receipt = synchronize({ sources: [source] }, { destination });
  assert.equal(receipt.revisions[source.id], ref);
  assert.ok(receipt.conceptCount > 1);
  const active = fs.readFileSync(path.join(destination, 'active.json'), 'utf8');
  try {
    synchronize({ sources: [{ ...source, root: source.root + '/datasets' }] }, { destination });
    report.strictSubdirectory = 'Unexpectedly accepted';
  } catch (error) {
    assert.equal(fs.readFileSync(path.join(destination, 'active.json'), 'utf8'), active);
    report.strictSubdirectory = error.message;
  }
  Object.assign(report, { status: 'PASS', receipt });
} catch (error) {
  Object.assign(report, { status: 'FAIL', error: error.message });
  process.exitCode = 1;
} finally { fs.rmSync(destination, { recursive: true, force: true }); }
fs.writeFileSync(path.join(root, 'results/evidence/public-git.json'), JSON.stringify(report, null, 2)+'\n');
console.log(JSON.stringify(report, null, 2));
