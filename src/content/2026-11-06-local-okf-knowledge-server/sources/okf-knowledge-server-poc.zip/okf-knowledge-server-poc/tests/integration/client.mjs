import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { Client } from '@modelcontextprotocol/client';
import { StdioClientTransport } from '@modelcontextprotocol/client/stdio';
import { activeProject, root, upstreamBin } from '../../src/knowledge.mjs';

export async function connect(mode, { project = activeProject(), args, env, cwd = root, timeout = 30_000, onStderr } = {}) {
  const serverArgs = args ?? (mode === 'native' ? [upstreamBin, '--project', project, 'mcp']
    : [path.join(root, 'src/server.mjs'), project]);
  const transport = new StdioClientTransport({
    command: process.execPath, args: serverArgs, cwd, stderr: 'pipe', env,
  });
  const client = new Client({ name: 'okf-poc-sdk', version: '0.1.0' },
    { versionNegotiation: { mode: 'legacy' } });
  let stderr = '';
  transport.stderr?.on('data', chunk => {
    stderr = (stderr + chunk).slice(-32_000);
    onStderr?.(stderr);
  });
  const start = performance.now();
  const timer = setTimeout(() => void transport.close(), timeout);
  try {
    await client.connect(transport);
  } catch (error) {
    await transport.close();
    throw new Error(`${error.message}${stderr ? '\n' + stderr : ''}`);
  } finally {
    clearTimeout(timer);
  }
  return {
    client, pid: transport.pid, startupMs: performance.now() - start, stderr: () => stderr,
    protocol: client.getNegotiatedProtocolVersion(), version: client.getServerVersion(),
    close: () => client.close(),
    async call(name, args = {}) {
      const response = await client.callTool({ name, arguments: args }, undefined, { timeout });
      const body = response.structuredContent ?? JSON.parse(response.content[0].text);
      if (response.isError) throw new Error(JSON.stringify(body));
      return body;
    },
  };
}
