import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { activeProject, fixtureProject, root, runtime } from '../src/knowledge.mjs';

const server = path.join(root, 'src/server.mjs');
const mode = process.argv[2];
if (mode === 'register') {
  const result = spawnSync('codex', ['mcp', 'add', 'corporate_knowledge', '--', process.execPath, server], { stdio: 'inherit' });
  process.exit(result.status ?? 1);
}
if (mode !== 'trial') throw new Error('Use register or trial');
const project = activeProject();
if (project !== fixtureProject) {
  const sources = Object.values(JSON.parse(fs.readFileSync(path.join(path.dirname(project), 'sources.json'), 'utf8')));
  if (!sources.length || sources.some(source => !source.repository.startsWith('fixture:'))) {
    throw new Error('The Codex trial only accepts synthetic sources. Select a synthetic fixture snapshot.');
  }
}
fs.mkdirSync(runtime, { recursive: true, mode: 0o700 });
const app = fs.mkdtempSync(path.join(runtime, 'codex-trial-'));
fs.cpSync(path.join(root, 'tests/codex-app'), app, { recursive: true });
const stateDir = path.join(app, 'codex-state');
fs.mkdirSync(stateDir);
const overrides = [
  ['sqlite_home', stateDir],
  ['log_dir', stateDir],
  ['mcp_servers.corporate_knowledge.command', process.execPath],
  ['mcp_servers.corporate_knowledge.args', [server, project]],
  ['mcp_servers.corporate_knowledge.enabled_tools', ['search_knowledge', 'read_knowledge']],
  ['mcp_servers.corporate_knowledge.required', true],
].flatMap(([key, value]) => ['-c', `${key}=${JSON.stringify(value)}`]);
const prompt = 'Implement a secured REST endpoint to create an order in this Spring Boot application according to our corporate engineering standards. Cite the Golden Sources you used. Keep the work in this application.';
const evidence = path.join(app, 'trial.jsonl');
const output = fs.openSync(evidence, 'w');
const stderr = fs.openSync(path.join(app, 'trial.stderr.log'), 'w');
const result = spawnSync('codex', ['exec', '--json', '--ephemeral', '--ignore-user-config', '--ignore-rules', '--skip-git-repo-check',
  '-C', app, '-s', 'workspace-write', ...overrides, prompt], { stdio: ['ignore', output, stderr], timeout: 180_000 });
fs.closeSync(output);
fs.closeSync(stderr);
const lines = fs.readFileSync(evidence, 'utf8').split('\n').filter(Boolean);
const events = lines.flatMap(line => { try { return [JSON.parse(line)]; } catch { return []; } });
const completed = events.filter(event => event.type === 'item.completed' && event.item?.type === 'mcp_tool_call');
console.log(JSON.stringify({ app, exitStatus: result.status, signal: result.signal, error: result.error?.code,
  completedCalls: completed.map(({ item }) => ({ server: item.server, tool: item.tool, status: item.status })),
  eventTypes: [...new Set(events.map(event => event.type))] }, null, 2));
process.exitCode = result.status ?? 1;
