import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { execFileSync } from 'node:child_process';
import { connect } from '../tests/integration/client.mjs';
import { root } from '../src/knowledge.mjs';
import { clockTicksPerSecond, processStats } from './process-stats.mjs';

const sizes = process.argv.slice(2).length ? process.argv.slice(2).map(Number) : [100, 1000, 5000, 10000];
if (sizes.some(n => !Number.isSafeInteger(n) || n < 5 || n > 20000 || n % 5)) throw new Error('Use multiples of five between 5 and 20000');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'okf-scale-'));
const topics = ['java logging exceptions', 'spring controllers transactions', 'rest pagination status', 'security oauth2 authorization', 'angular reactive components'];
const rows = [];
const directLoadScript = `
  import { performance } from 'node:perf_hooks';
  import okf from '@mfdaves/okf-mcp';
  import { knowledgeService, loadKnowledge } from './src/knowledge.mjs';
  const [mode, project, expected] = process.argv.slice(1);
  const start = performance.now();
  const load = mode === 'native' ? { index: okf.buildProjectIndex(project) } : loadKnowledge(project);
  if (mode === 'adapter') knowledgeService(load);
  if (load.index.concepts.length !== Number(expected)) throw new Error('Unexpected scale concept count');
  console.log(performance.now() - start);
`;
const target = path.join(root, 'results/scale.json');
const quantiles = samples => {
  const sorted = [...samples].sort((a,b) => a-b);
  return { n: sorted.length, p50: sorted[Math.ceil(sorted.length*.5)-1], p95: sorted[Math.ceil(sorted.length*.95)-1], samples };
};
const measure = async call => {
  const before = performance.now();
  await call();
  return performance.now() - before;
};
function createProject(n) {
  const dir = path.join(temp, String(n));
  fs.mkdirSync(dir);
  const bundles = [];
  const manifest = {};
  for (let b = 0; b < 5; b++) {
    const id = `bundle-${b}`;
    bundles.push({ id, root: id });
    manifest[id] = { repository: `synthetic:${id}`, reviewers: ['human:fixture'] };
    fs.mkdirSync(path.join(dir,id));
    for (let i = 0; i < n / 5; i++) {
      const slug = `rule-${i}`;
      const next = `okf://bundle-${(b+1)%5}/${slug}`;
      const fm = {
        type: 'Standard', title: `${topics[b]} rule ${i}`, description: `Synthetic variation for ${topics[b]}`,
        tags: [topics[b].split(' ')[0]], technology: topics[b].split(' ')[0], status: 'stable',
        verified: { by: 'human:fixture', at: '2026-01-01T00:00:00Z' },
        relations: [{ type: 'related_to', target: next }],
      };
      const yaml = Object.entries(fm).map(([key,value]) => `${key}: ${JSON.stringify(value)}`).join('\n');
      fs.writeFileSync(path.join(dir,id,`${slug}.md`), `---\n${yaml}\n---\n\n# Rule ${i}\n\n${topics[b]}. Use invariant marker-${i} for the approved process and preserve evidence.\n`);
    }
  }
  const project = path.join(dir, 'okf.project.yaml');
  fs.writeFileSync(project, JSON.stringify({ project: 'scale benchmark', languages: ['en'], bundles }));
  fs.writeFileSync(path.join(dir, 'sources.json'), JSON.stringify(manifest));
  return project;
}
const platform = { os: os.type(), kernelBuild: os.version(), release: os.release(), arch: os.arch(), node: process.version,
  availableParallelism: os.availableParallelism(), cpu: os.cpus()[0]?.model, reportedMemoryGiB: os.totalmem()/2**30 };
platform.cpuTicksPerSecond = clockTicksPerSecond();
try {
  for (const n of sizes) {
    const project = createProject(n);
    for (const mode of ['native','adapter']) {
      const startup = [], directLoad = [], cold = [], steady = [], graph = [], concurrent = [];
      const resourceSamples = [];
      let restartAfterEditMs;
      for (let repetition = 0; repetition < 3; repetition++) {
        directLoad.push(Number(execFileSync(process.execPath, ['--input-type=module', '-e', directLoadScript, mode, project, String(n)],
          { cwd: root, encoding: 'utf8', timeout: 90_000 }).trim()));
        const connection = await connect(mode, { project, timeout: 90_000 });
        try {
          const search = (i, broad = false) => connection.call(mode === 'native' ? 'search_concepts' : 'search_knowledge',
            { query: broad ? topics[i%5] : `${topics[i%5]} marker-${i%(n/5)}`, limit: 5 });
          startup.push(connection.startupMs);
          const start = processStats(connection.pid);
          cold.push(await measure(() => search(0)));
          for (let i=0; i<5; i++) await search(i);
          for (let i=0; i<30; i++) steady.push(await measure(() => search(i, i%3 === 0)));
          if (mode === 'native') for (let i=0; i<15; i++) {
            graph.push(await measure(() => connection.call('get_subgraph', { uri: `okf://bundle-0/rule-${i%(n/5)}`, depth: 2 })));
          }
          for (let batch=0; batch<5; batch++) concurrent.push(await measure(() =>
            Promise.all(Array.from({ length: 8 }, (_, i) => search(i+batch)))));
          const after = processStats(connection.pid);
          resourceSamples.push({ start, after, cpuDeltaMs: after.cpuTicks === undefined || !platform.cpuTicksPerSecond ? null :
            1000*(after.cpuTicks-start.cpuTicks)/platform.cpuTicksPerSecond });
        } finally { await connection.close(); }
      }
      const modified = path.join(path.dirname(project), 'bundle-0/rule-0.md');
      const original = fs.readFileSync(modified, 'utf8');
      fs.appendFileSync(modified, '\nrevisionmarker\n');
      try {
        const before = performance.now();
        const connection = await connect(mode, { project, timeout: 90_000 });
        try {
          const response = await connection.call(mode === 'native' ? 'search_concepts' : 'search_knowledge',
            { query: 'revisionmarker', limit: 1 });
          if (response.results[0]?.uri !== 'okf://bundle-0/rule-0') throw new Error('Edit not indexed');
          restartAfterEditMs = performance.now() - before;
        } finally { await connection.close(); }
      } finally { fs.writeFileSync(modified, original); }
      const row = { concepts: n, mode, directLoadMs: quantiles(directLoad), startupMs: quantiles(startup), coldSearchMs: quantiles(cold),
        searchMs: quantiles(steady), graphMs: graph.length ? quantiles(graph) : null,
        concurrentBatch8Ms: quantiles(concurrent), resourceSamples, restartAfterEditMs };
      rows.push(row);
      console.log(JSON.stringify({ concepts:n, mode, startupMs:row.startupMs.p50, searchP95Ms:row.searchMs.p95,
        rssMiB:Math.max(...resourceSamples.map(s=>s.after.rssMiB ?? 0)), restartAfterEditMs }));
      fs.writeFileSync(target, JSON.stringify({ platform, conditions: 'Three fresh child processes per mode and size; 5 warmups, 30 timed queries, 5 batches of 8 each. Every third timed query broad. Sequential modes. Direct load uses separate fresh processes and excludes Node startup and imports. Linux /proc RSS and CPU child samples.', rows }, null, 2)+'\n');
    }
  }
} finally { fs.rmSync(temp, { recursive: true, force: true }); }
