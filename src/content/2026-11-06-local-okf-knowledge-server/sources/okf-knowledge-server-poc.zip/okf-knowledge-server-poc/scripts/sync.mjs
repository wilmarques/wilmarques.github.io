import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { runtime, loadKnowledge } from '../src/knowledge.mjs';

const idPattern = /^[a-z0-9][a-z0-9-]{0,63}$/;
const remotePattern = /^(?:https:\/\/github\.com\/|git@github\.com:)([a-zA-Z0-9-]+)\/([a-zA-Z0-9_.-]+?)(?:\.git)?$/;
const gitEnv = () => Object.fromEntries(Object.entries(process.env).filter(([name]) =>
  !['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'].includes(name)));

export function git(cwd, args, extraEnv = {}) {
  const response = spawnSync('git', ['-c', 'core.hooksPath=.git/no-hooks', '-c', 'core.autocrlf=false',
    '-c', 'fetch.recurseSubmodules=false', ...args],
    { cwd, encoding: 'utf8', timeout: 120_000, maxBuffer: 16 * 1024 * 1024, env: { ...gitEnv(), ...extraEnv }, stdio: ['ignore', 'pipe', 'pipe'] });
  if (response.status !== 0) throw new Error(`Git ${args[0]} failed (${response.error?.code ?? response.status ?? response.signal})`);
  return response.stdout.trim();
}

function parseSource(entry, allowLocal) {
  const { id, url, ref, root = '.', reviewers } = entry;
  if (!idPattern.test(id) || typeof ref !== 'string' || ref.startsWith('-') || /[\s:~^?*\\[\x00-\x1f]/.test(ref) ||
      !Array.isArray(reviewers) || !reviewers.length || reviewers.some(r => typeof r !== 'string' || !r.startsWith('human:'))) {
    throw new Error('Invalid source id, ref, or reviewers');
  }
  if (root !== '.' && !root.split('/').every(part => /^[A-Za-z0-9_.-]+$/.test(part) && !['.','..','.git'].includes(part.toLowerCase()))) {
    throw new Error('Invalid bundle root');
  }
  const github = typeof url === 'string' && remotePattern.exec(url);
  if (github && !['.','..'].includes(github[2])) {
    const repository = `${github[1]}/${github[2]}`;
    return { id, url, ref, root, reviewers, repository, web: `https://github.com/${repository}` };
  }
  if (allowLocal && typeof url === 'string' && path.isAbsolute(url)) {
    return { id, url, ref, root, reviewers, repository: `fixture:${id}` };
  }
  throw new Error('Only credential-free GitHub HTTPS or SSH repository URLs are accepted');
}

export function synchronize(config, { destination = runtime, allowLocal = false } = {}) {
  if (!Array.isArray(config.sources) || !config.sources.length) throw new Error('Missing sources');
  const entries = config.sources.map(source => parseSource(source, allowLocal));
  if (new Set(entries.map(source => source.id)).size !== entries.length) throw new Error('Duplicate source ids');
  fs.mkdirSync(destination, { recursive: true, mode: 0o700 });
  const stage = fs.mkdtempSync(path.join(destination, 'snapshot-'));
  const pointerTemp = path.join(stage, 'next-active.json');
  const generation = path.basename(stage);
  const manifest = Object.create(null);
  const bundles = [];
  try {
    for (const entry of entries) {
      const relative = path.posix.join('repos', entry.id);
      const repo = path.join(stage, relative);
      fs.mkdirSync(repo, { recursive: true });
      try {
        git(repo, ['init', '--quiet', '--template=']);
        git(repo, ['fetch', '--no-tags', '--depth=1', '--no-recurse-submodules', '--', entry.url, entry.ref]);
        const commit = git(repo, ['rev-parse', '--verify', 'FETCH_HEAD^{commit}']);
        if (!/^[0-9a-f]{40}$/.test(commit)) throw new Error('Expected a SHA-1 Git commit');
        const files = git(repo, ['ls-tree', '-r', '-z', commit]).split('\0').filter(Boolean);
        const blobs = files.map(file => {
          const tab = file.indexOf('\t');
          const [mode, type, sha] = file.slice(0, tab).split(' ');
          if (type !== 'blob' || !['100644', '100755'].includes(mode)) {
            throw new Error('Repository contains symlinks, submodules, or unsupported entries');
          }
          return { relativePath: file.slice(tab + 1), sha };
        });
        // Only fetch uses the developer's normal credential configuration.
        // Checkout ignores global filter drivers and verifies exact Git bytes.
        git(repo, ['-c', 'advice.detachedHead=false', 'checkout', '--quiet', '--detach', commit], {
          GIT_CONFIG_GLOBAL: process.platform === 'win32' ? 'NUL' : '/dev/null',
          GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_COUNT: '0', GIT_CONFIG_PARAMETERS: '',
          GIT_ATTR_NOSYSTEM: '1',
        });
        for (const { relativePath, sha } of blobs) {
          const bytes = fs.readFileSync(path.join(repo, relativePath));
          const digest = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
          if (digest !== sha) throw new Error('Working copy bytes differ from the pinned Git blob');
        }
        manifest[entry.id] = { repository: entry.repository, web: entry.web, commit,
          prefix: entry.root === '.' ? '' : entry.root, reviewers: entry.reviewers };
        bundles.push({ id: entry.id, root: path.posix.join(relative, entry.root) });
      } catch (error) {
        throw new Error(`Source ${entry.id}: ${error.message}`);
      }
    }
    const project = path.join(stage, 'okf.project.yaml');
    fs.writeFileSync(project, JSON.stringify({ project: 'Managed Golden Sources', languages: ['en'], strictLinks: true, bundles }, null, 2));
    fs.writeFileSync(path.join(stage, 'sources.json'), JSON.stringify(manifest, null, 2));
    const { index } = loadKnowledge(project);
    fs.writeFileSync(pointerTemp, JSON.stringify({ generation }) + '\n');
    fs.renameSync(pointerTemp, path.join(destination, 'active.json'));
    return { generation, conceptCount: index.concepts.length, revisions: Object.fromEntries(
      Object.entries(manifest).map(([id, item]) => [id, item.commit])) };
  } catch (error) {
    fs.rmSync(stage, { recursive: true, force: true });
    throw error;
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    if (!process.argv[2]) throw new Error('Usage: npm run sync -- /path/to/sources.json');
    const config = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
    console.log(JSON.stringify(synchronize(config), null, 2));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
