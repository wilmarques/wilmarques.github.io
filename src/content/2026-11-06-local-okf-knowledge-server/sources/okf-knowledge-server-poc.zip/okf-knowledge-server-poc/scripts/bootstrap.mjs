import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(import.meta.dirname, '..');
const [major] = process.versions.node.split('.').map(Number);
if (major < 22) throw new Error('Node 22 or newer is required');
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
function run(command, args, shell = false) {
  const result = spawnSync(command, args, { cwd: root, stdio: 'inherit', shell });
  if (result.status !== 0) process.exit(result.status ?? 1);
}
run('git', ['--version']);
run(npm, ['ci', '--ignore-scripts', '--no-fund'], process.platform === 'win32');
run(process.execPath, [path.join(root, 'scripts/setup.mjs')]);
