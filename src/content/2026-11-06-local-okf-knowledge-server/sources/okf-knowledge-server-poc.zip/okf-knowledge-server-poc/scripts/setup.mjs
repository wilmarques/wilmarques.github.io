import fs from 'node:fs';
import path from 'node:path';
import { fixtureReviewers, root, runtime } from '../src/knowledge.mjs';
import { git, synchronize } from './sync.mjs';

const origins = path.join(runtime, 'fixture-origins');
fs.mkdirSync(origins, { recursive: true, mode: 0o700 });
const sources = [];
for (const [id, reviewer] of Object.entries(fixtureReviewers)) {
  const repo = path.join(origins, id);
  if (!fs.existsSync(path.join(repo, '.git'))) {
    fs.cpSync(path.join(root, 'golden-sources', id), repo, { recursive: true });
    git(repo, ['init', '--quiet', '--initial-branch=main']);
    git(repo, ['add', '--all']);
    const date = '2026-07-10T00:00:00Z';
    git(repo, ['-c', 'user.name=POC Fixture', '-c', 'user.email=fixture@example.invalid',
      '-c', 'commit.gpgsign=false', 'commit', '--quiet', '-m', 'Synthetic OKF Golden Source'],
      { GIT_AUTHOR_DATE: date, GIT_COMMITTER_DATE: date });
  }
  sources.push({ id, url: repo, ref: 'main', reviewers: [`human:${reviewer}`] });
}
console.log(JSON.stringify(synchronize({ sources }, { allowLocal: true }), null, 2));
