import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

export function clockTicksPerSecond() {
  if (process.platform !== 'linux') return null;
  try { return Number(execFileSync('getconf', ['CLK_TCK'], { encoding: 'utf8' }).trim()); }
  catch { return null; }
}

export function processStats(pid) {
  if (process.platform !== 'linux') return {};
  try {
    const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8').split(') ').at(-1).split(' ');
    const status = fs.readFileSync(`/proc/${pid}/status`, 'utf8');
    return { rssMiB: Number(status.match(/^VmRSS:\s+(\d+)/m)?.[1]) / 1024,
      highWaterRssMiB: Number(status.match(/^VmHWM:\s+(\d+)/m)?.[1]) / 1024,
      cpuTicks: Number(stat[11]) + Number(stat[12]) };
  } catch { return {}; }
}
