import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
import { connect } from '../tests/integration/client.mjs';
import { activeProject, fixtureReviewers, root } from '../src/knowledge.mjs';

const ids = Object.keys(fixtureReviewers);
const bundleNames = Object.fromEntries(['j','s','r','x','a'].map((key,i) => [key, ids[i]]));
const uri = short => {
  const [bundle, id] = short.split('/');
  return `okf://${bundleNames[bundle]}/${id}`;
};
const columns = list => list ? list.split(',') : [];
const file = path.join(root, 'tests/retrieval/judgments.tsv');
const data = fs.readFileSync(file, 'utf8');
const hash = createHash('sha256').update(data).digest('hex');
const expectedHash = fs.readFileSync(path.join(root, 'results/evidence/judgments-before-execution.sha256'), 'utf8').split(/\s/)[0];
if (hash !== expectedHash) throw new Error('Judgments differ from their frozen hash');
const judgments = data.trimEnd().split('\n').slice(1).map(line => {
  const [id, category, natural, keywords, relevant, primary, edges, authority, excluded] = line.split('\t');
  return { id, category, natural, keywords, relevant: columns(relevant).map(uri), primary: uri(primary),
    edges: columns(edges).map(edge => edge.split('>').map(uri).join('>')),
    authority: authority ? uri(authority) : null, excluded: columns(excluded).map(uri) };
});
const projectDir = path.dirname(activeProject());
const sourceFile = path.join(projectDir, 'sources.json');
if (!fs.existsSync(sourceFile)) throw new Error('Run npm run setup before the fixture benchmark');
const manifest = JSON.parse(fs.readFileSync(sourceFile, 'utf8'));
if (Object.keys(manifest).sort().join() !== [...ids].sort().join() || Object.values(manifest).some(item => !item.repository.startsWith('fixture:'))) {
  throw new Error('The retrieval benchmark requires the five synthetic fixtures');
}
const baseline = new Map();
for (const bundle of ids) {
  const repo = path.join(projectDir, 'repos', bundle);
  const commit = execFileSync('git', ['-C', repo, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  const files = execFileSync('git', ['-C', repo, 'ls-tree', '-r', '--name-only', commit], { encoding: 'utf8' }).trim().split('\n');
  for (const file of files.filter(name => name.endsWith('.md') && name !== 'index.md')) {
    const id = file.slice(0, -3);
    baseline.set(`okf://${bundle}/${id}`, { bundle, id, file, commit, repository: `fixture:${bundle}` });
  }
}
const bundleOf = id => id.split('/')[2];
const rows = [];
const sessions = {};
const modes = ['native', 'native-filtered', 'adapter'];
for (const mode of modes) {
  const isNative = mode !== 'adapter';
  const connection = await connect(isNative ? 'native' : mode);
  try {
    const name = isNative ? 'search_concepts' : 'search_knowledge';
    sessions[mode] = { version: connection.version, protocol: connection.protocol, startupMs: connection.startupMs };
    for (const q of judgments) for (const form of ['natural','keywords']) {
      let response = { results: [] }, error = null;
      const args = { query: q[form], limit: 5, ...(isNative ? { detail: 'full' } : {}),
        ...(mode === 'native-filtered' ? { types: ['Standard'], statuses: ['stable'],
          trustTiers: ['human-reviewed'], freshness: ['fresh','unspecified'], freshnessPrior: true } : {}) };
      const start = performance.now();
      try { response = await connection.call(name, args); } catch (failure) { error = failure.message; }
      const latencyMs = performance.now() - start;
      const results = response.results ?? [];
      const returned = results.map(hit => hit.uri);
      const valid = new Set(q.relevant);
      const found = returned.filter(hit => valid.has(hit));
      const first = returned.findIndex(hit => valid.has(hit));
      const covered = new Set(found.map(bundleOf));
      const expectedBundles = new Set(q.relevant.map(bundleOf));
      const citations = results.map(hit => {
        const expected = baseline.get(hit.uri);
        return {
          localIdentityCorrect: !!expected && (hit.bundle ?? hit.citation?.bundle) === expected.bundle &&
            (hit.path ?? hit.citation?.path) === expected.file &&
            (hit.conceptId ?? hit.citation?.conceptId) === expected.id,
          fullCitationCorrect: !!expected && hit.citation?.repository === expected.repository &&
            hit.citation?.commit === expected.commit && hit.citation?.path === expected.file &&
            hit.citation?.conceptId === expected.id && hit.citation?.bundle === expected.bundle,
        };
      });
      // Test native graph traversal from retrieved seeds, with no oracle URI
      // passed to the server. Graph calls are timed separately from search.
      let edges = response.relationships ?? [];
      let graphMs = null;
      const graphErrors = [];
      if (isNative && q.category === 'C') {
        const graphStart = performance.now();
        for (const seed of returned) {
          try {
            const neighbors = await connection.call('get_neighbors', { uri: seed, edgeKinds: ['relation'] });
            edges.push(...[...neighbors.inbound, ...neighbors.outbound].map(item => item.edge));
          } catch (failure) { graphErrors.push(failure.message); }
        }
        graphMs = performance.now() - graphStart;
      }
      const edgesFound = new Set(edges.map(edge => `${edge.source}>${edge.target}`));
      const policy = response.policyDecisions?.find(item => item.selected === q.authority);
      const excludedFromResults = q.excluded.every(id => !returned.includes(id));
      rows.push({
        id: q.id, category: q.category, mode, form, query: q[form], expected: q.relevant,
        expectedTop1: q.primary, expectedEdges: q.edges, expectedAuthority: q.authority, excluded: q.excluded,
        returned, results, relationships: edges, policyDecisions: response.policyDecisions ?? [], citations,
        latencyMs, graphMs, graphErrors, error, precision5: found.length / 5, recall5: found.length / valid.size,
        reciprocalRank: first < 0 ? 0 : 1 / (first + 1), top1: returned[0] === q.primary,
        crossRepo: q.category === 'B' ? expectedBundles.size >= 2 && [...expectedBundles].every(b => covered.has(b)) : null,
        edgeSuccess: q.category === 'C' ? q.edges.every(edge => edgesFound.has(edge)) : null,
        authority: q.category === 'D' ? returned[0] === q.authority && excludedFromResults : null,
        lifecycle: q.category === 'D' ? excludedFromResults : null,
        lifecycleExplained: q.category === 'D' ? !!policy && q.excluded.every(id =>
          policy.candidates.some(item => item.uri === id && !item.approved && !!item.status && !!item.freshness)) : null,
      });
    }
  } finally { await connection.close(); }
}
const mean = values => values.length ? values.reduce((sum, value) => sum + Number(value), 0) / values.length : null;
const quantile = (values, p) => [...values].sort((a,b) => a-b)[Math.ceil(values.length*p)-1];
function summarize(selection) {
  const metric = name => mean(selection.map(row => row[name]).filter(value => value !== null));
  const citations = selection.flatMap(row => row.citations);
  const calls = selection.length + selection.filter(row => row.graphMs !== null).reduce((sum,row) => sum+row.returned.length,0);
  return { n: selection.length, precision5: metric('precision5'), recall5: metric('recall5'),
    mrr: metric('reciprocalRank'), top1: metric('top1'), crossRepo: metric('crossRepo'),
    relationshipSuccess: metric('edgeSuccess'), authority: metric('authority'), lifecycle: metric('lifecycle'),
    lifecycleExplained: metric('lifecycleExplained'),
    localIdentityCorrect: mean(citations.map(item => item.localIdentityCorrect)),
    fullCitationCorrect: mean(citations.map(item => item.fullCitationCorrect)),
    p50Ms: quantile(selection.map(row => row.latencyMs), .50), p95Ms: quantile(selection.map(row => row.latencyMs), .95),
    calls, errorRate: (selection.filter(row => row.error).length + selection.flatMap(row => row.graphErrors).length) / calls };
}
const precision5Ceiling = mean(judgments.map(item => Math.min(5, item.relevant.length) / 5));
const summary = Object.fromEntries(modes.map(mode => [mode, Object.fromEntries(
  ['all','natural','keywords'].map(form => [form, summarize(rows.filter(row =>
    row.mode === mode && (form === 'all' || row.form === form)))])
)]));
fs.writeFileSync(path.join(root, 'results/benchmark.json'), JSON.stringify({ judgmentSha256: hash, precision5Ceiling, sessions, summary, rows }, null, 2) + '\n');
const fields = ['id','category','mode','form','query','expected','returned','precision5','recall5','reciprocalRank',
  'top1','crossRepo','edgeSuccess','authority','lifecycle','lifecycleExplained','latencyMs','error'];
const csv = value => '"' + (Array.isArray(value) ? value.join(' ') : String(value ?? '')).replaceAll('"','""') + '"';
fs.writeFileSync(path.join(root, 'results/benchmark.csv'), [fields.join(','),
  ...rows.map(row => fields.map(field => csv(row[field])).join(','))].join('\n') + '\n');
console.log(JSON.stringify(summary, null, 2));
