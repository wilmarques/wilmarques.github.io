# Evidence index

These receipts were generated during the POC. Machine paths in selected logs were replaced with `<poc-root>` and `<codex-home>`. The Codex JSONL files were empty in both attempts, so the exit receipts and stderr are preserved. No access tokens or corporate documents were used.

| Evidence | Files |
|---|---|
| Package and GitHub release metadata | [npm-versions.json](npm-versions.json), [npm-rc-pin.json](npm-rc-pin.json), [upstream-tags.txt](upstream-tags.txt), [github-releases.json](github-releases.json), [github-issues.json](github-issues.json) |
| Upstream test suite | [upstream-tests.log](upstream-tests.log) |
| Exact stock dependency input | [package.json](stock-dependencies/package.json), [package-lock.json](stock-dependencies/package-lock.json) |
| Stock observations | [stock-integration.json](stock-integration.json), [stock-retrieval-summary.json](stock-retrieval-summary.json), [stock-scale.json](stock-scale.json), [npm-audit-stock.json](npm-audit-stock.json) |
| Patched dependency setup and audit | [bootstrap.log](bootstrap.log), [patched-install.log](patched-install.log), [dependency-tree.txt](dependency-tree.txt), [npm-audit.json](npm-audit.json) |
| Current MCP integration, sync and security | [test-results.json](../test-results.json), [integration-console.log](integration-console.log) |
| Fresh ZIP extraction verification | [fresh-extract.log](fresh-extract.log) |
| Frozen judgments and retrieval | [judgment hash](judgments-before-execution.sha256), [benchmark.json](../benchmark.json), [benchmark.csv](../benchmark.csv), [retrieval-console.log](retrieval-console.log) |
| Performance samples | [scale.json](../scale.json), [scale-console.log](scale-console.log) |
| Public GitHub API and standard Git tests | [remote.json](remote.json), [remote-console.log](remote-console.log), [public-git.json](public-git.json), [public-git-console.log](public-git-console.log) |
| Codex local CLI config | [codex-config-list.json](codex-config-list.json) |
| Codex initial run | [exit receipt](codex-trial-console.log), [stderr](codex-first.stderr.log) |
| Codex writable state retry | [exit receipt](codex-retry-console.log), [stderr](codex-retry.stderr.log) |

## Commands executed

From separate upstream and specification checkouts:

```sh
git clone https://github.com/mfdaves/okf-mcp
git -C okf-mcp checkout --detach d10a05528289cb4a3440e7ea3c4b567d351a44d6
git -C okf-mcp tag --sort=-version:refname
git clone https://github.com/GoogleCloudPlatform/open-knowledge-format
git -C open-knowledge-format rev-parse HEAD
cd okf-mcp
npm ci --ignore-scripts --no-fund
npm test
npm view @mfdaves/okf-mcp dist-tags versions --json
npm view @mfdaves/okf-mcp@0.12.0-rc.1 gitHead dist.integrity --json
```

From the POC root:

```sh
node scripts/bootstrap.mjs
npm test
npm run benchmark
npm run scale
npm run remote
npm run git:public
npm ls --all
npm audit --omit=dev --json
sha256sum -c results/evidence/judgments-before-execution.sha256
codex --version
codex login status
npm run codex:trial
```

The optional stable control was installed separately with `npm install --ignore-scripts --no-fund @mfdaves/okf-mcp@0.9.1`. Tests used `OKF_STABLE_BIN` pointing to that installation's absolute bin file. Native integration requests and authority assertions are in `tests/integration/run.mjs`. The Codex config list used `codex mcp list --json` plus transient `mcp_servers.corporate_knowledge.command` and `args` overrides. It reported an enabled stdio entry and performs no tool discovery. The retry also configured a writable `sqlite_home` and `log_dir`. Both attempts failed before an MCP call.
