---
type: "Standard"
title: "Angular accessibility"
description: "Use semantic HTML and native interactive elements."
tags: ["angular", "accessibility"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/accessibility", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
---

# Angular accessibility

## Rule

Use semantic HTML and native interactive elements. Support keyboard navigation, visible focus and programmatic labels. Test against WCAG 2.2 AA.[^policy]

[^policy]: Synthetic review record.
