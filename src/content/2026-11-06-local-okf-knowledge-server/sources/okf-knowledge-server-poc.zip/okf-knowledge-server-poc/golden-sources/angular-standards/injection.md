---
type: "Standard"
title: "Angular dependency injection"
description: "Use inject() in an Angular injection context and provide app-wide services in root."
tags: ["angular", "injection"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/injection", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
---

# Angular dependency injection

## Rule

Use inject() in an Angular injection context and provide app-wide services in root. Use feature providers for scoped lifetimes.[^policy]

[^policy]: Synthetic review record.
