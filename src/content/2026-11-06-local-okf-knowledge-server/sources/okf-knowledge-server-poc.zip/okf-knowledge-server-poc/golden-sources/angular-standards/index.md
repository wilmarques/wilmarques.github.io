---
okf_version: "0.2"
---

# angular-standards

## Standards

- [Angular component architecture](components.md): Use standalone Angular components.
- [Angular dependency injection](injection.md): Use inject() in an Angular injection context and provide app-wide services in root.
- [Angular routing and lazy loading](routing.md): Lazy load feature routes with loadChildren or loadComponent.
- [Angular reactive patterns](reactivity.md): Use signals for synchronous view state and RxJS for asynchronous streams.
- [Angular state management](state.md): Keep state local by default.
- [Angular accessibility](accessibility.md): Use semantic HTML and native interactive elements.
- [Angular component testing](tests.md): Use TestBed and harnesses to test observable behavior.
- [Legacy Angular global store](state-global.md): A 2023 design put all view state into a global NgRx Store, including per-component state.
