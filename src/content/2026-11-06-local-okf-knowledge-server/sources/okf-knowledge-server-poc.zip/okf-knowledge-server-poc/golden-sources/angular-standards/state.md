---
type: "Standard"
title: "Angular state management"
description: "Keep state local by default."
tags: ["angular", "state"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/state", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "angular-state"
relations: [{"type": "supersedes", "target": "okf://angular-standards/state-global"}]
---

# Angular state management

## Rule

Keep state local by default. Use a feature signal store for shared feature state and use NgRx Store only for justified cross-feature workflows.[^policy]

[^policy]: Synthetic review record.
