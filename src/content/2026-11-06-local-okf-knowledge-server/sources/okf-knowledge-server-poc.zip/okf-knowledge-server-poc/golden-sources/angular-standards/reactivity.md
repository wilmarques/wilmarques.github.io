---
type: "Standard"
title: "Angular reactive patterns"
description: "Use signals for synchronous view state and RxJS for asynchronous streams."
tags: ["angular", "reactivity"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/reactivity", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://angular-standards/state"}]
---

# Angular reactive patterns

## Rule

Use signals for synchronous view state and RxJS for asynchronous streams. Use switchMap for cancelable requests and takeUntilDestroyed when subscribing manually.[^policy]

[^policy]: Synthetic review record.
