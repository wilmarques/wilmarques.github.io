---
type: "Standard"
title: "Angular component testing"
description: "Use TestBed and harnesses to test observable behavior."
tags: ["angular", "tests"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/tests", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
---

# Angular component testing

## Rule

Use TestBed and harnesses to test observable behavior. Prefer role-based queries and stub the HTTP backend with HttpTestingController.[^policy]

[^policy]: Synthetic review record.
