---
type: "Standard"
title: "Angular routing and lazy loading"
description: "Lazy load feature routes with loadChildren or loadComponent."
tags: ["angular", "routing"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/routing", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
---

# Angular routing and lazy loading

## Rule

Lazy load feature routes with loadChildren or loadComponent. Use functional guards for navigation and enforce real authorization on the server.[^policy]

[^policy]: Synthetic review record.
