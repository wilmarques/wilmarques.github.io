---
type: "Standard"
title: "Angular component architecture"
description: "Use standalone Angular components."
tags: ["angular", "components"]
technology: "angular"
status: "stable"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/components", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
---

# Angular component architecture

## Rule

Use standalone Angular components. Split feature orchestration from presentational components and prefer explicit inputs and outputs.[^policy]

[^policy]: Synthetic review record.
