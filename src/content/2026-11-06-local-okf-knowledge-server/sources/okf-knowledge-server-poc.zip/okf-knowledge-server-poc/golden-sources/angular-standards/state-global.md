---
type: "ADR"
title: "Legacy Angular global store"
description: "A 2023 design put all view state into a global NgRx Store, including per-component state."
tags: ["angular", "state-global"]
technology: "angular"
status: "deprecated"
generated: {"by": "human:web-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/angular-standards/state-global", "title": "Synthetic review record", "author": "human:web-council"}]
verified: [{"by": "human:web-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "angular-state"
relations: [{"type": "related_to", "target": "okf://angular-standards/state"}]
---

# Legacy Angular global store

## Rule

A 2023 design put all view state into a global NgRx Store, including per-component state.[^policy]

[^policy]: Synthetic review record.
