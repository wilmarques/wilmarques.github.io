---
type: "Standard"
title: "REST pagination"
description: "Use opaque cursor pagination, deterministic ordering with a tie-breaker and a maximum page size of 100."
tags: ["rest api", "pagination"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/pagination", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "pagination"
relations: [{"type": "supersedes", "target": "okf://rest-api-standards/pagination-offset"}]
---

# REST pagination

## Rule

Use opaque cursor pagination, deterministic ordering with a tie-breaker and a maximum page size of 100. Return nextCursor only when more results exist.[^policy]

[^policy]: Synthetic review record.
