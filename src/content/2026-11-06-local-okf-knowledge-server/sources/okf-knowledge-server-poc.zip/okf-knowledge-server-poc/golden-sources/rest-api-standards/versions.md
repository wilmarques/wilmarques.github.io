---
type: "Standard"
title: "REST API versioning"
description: "Use the /v1 path prefix for public REST APIs."
tags: ["rest api", "versions"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/versions", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "api-version"
relations: [{"type": "related_to", "target": "okf://rest-api-standards/urls"}, {"type": "supersedes", "target": "okf://rest-api-standards/versions-header"}]
---

# REST API versioning

## Rule

Use the /v1 path prefix for public REST APIs. Introduce a new major path for breaking changes and preserve the old contract during migration.[^policy]

[^policy]: Synthetic review record.
