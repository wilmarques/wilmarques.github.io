---
type: "Recommendation"
title: "Draft REST offset pagination"
description: "A draft proposes page numbers, limit and offset for all endpoints."
tags: ["rest api", "pagination-offset"]
technology: "rest api"
status: "draft"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/pagination-offset", "title": "Synthetic review record", "author": "human:api-council"}]
policy_key: "pagination"
relations: [{"type": "related_to", "target": "okf://rest-api-standards/pagination"}]
---

# Draft REST offset pagination

## Rule

A draft proposes page numbers, limit and offset for all endpoints.[^policy]

[^policy]: Synthetic review record.
