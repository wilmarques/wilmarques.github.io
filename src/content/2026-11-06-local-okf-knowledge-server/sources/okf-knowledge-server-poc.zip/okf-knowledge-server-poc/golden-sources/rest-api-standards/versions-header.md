---
type: "Recommendation"
title: "Old REST header versioning"
description: "An older recommendation uses X-API-Version for public REST API versioning."
tags: ["rest api", "versions-header"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/versions-header", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "api-version"
stale_after: "2026-01-01T00:00:00Z"
relations: [{"type": "related_to", "target": "okf://rest-api-standards/versions"}]
---

# Old REST header versioning

## Rule

An older recommendation uses X-API-Version for public REST API versioning.[^policy]

[^policy]: Synthetic review record.
