---
okf_version: "0.2"
---

# rest-api-standards

## Standards

- [REST URL design](urls.md): Use lowercase plural noun collection paths and hyphenated segments.
- [REST HTTP method semantics](methods.md): GET is safe and idempotent.
- [REST HTTP status codes](status.md): Return 201 Created with Location for successful creation, 204 for successful deletion without a body, 400 for malformed input, 401 for missing credentials, and 403 for insufficient privileges.
- [REST API versioning](versions.md): Use the /v1 path prefix for public REST APIs.
- [REST pagination](pagination.md): Use opaque cursor pagination, deterministic ordering with a tie-breaker and a maximum page size of 100.
- [REST API problem details](errors.md): Return RFC 9457 application/problem+json with type, title, status, detail and instance.
- [REST OpenAPI documentation](openapi.md): Publish OpenAPI 3.1 contracts.
- [Legacy REST custom error envelope](errors-envelope.md): Wrap REST errors in a custom code and message JSON object from the old API gateway.
- [Draft REST offset pagination](pagination-offset.md): A draft proposes page numbers, limit and offset for all endpoints.
- [Old REST header versioning](versions-header.md): An older recommendation uses X-API-Version for public REST API versioning.
