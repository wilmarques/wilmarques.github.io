---
type: "Standard"
title: "Legacy REST custom error envelope"
description: "Wrap REST errors in a custom code and message JSON object from the old API gateway."
tags: ["rest api", "errors-envelope"]
technology: "rest api"
status: "deprecated"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/errors-envelope", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "api-errors"
relations: [{"type": "related_to", "target": "okf://rest-api-standards/errors"}]
---

# Legacy REST custom error envelope

## Rule

Wrap REST errors in a custom code and message JSON object from the old API gateway.[^policy]

[^policy]: Synthetic review record.
