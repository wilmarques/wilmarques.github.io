---
type: "Standard"
title: "REST OpenAPI documentation"
description: "Publish OpenAPI 3.1 contracts."
tags: ["rest api", "openapi"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/openapi", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://rest-api-standards/errors"}, {"type": "related_to", "target": "okf://spring-boot-standards/dtos"}]
---

# REST OpenAPI documentation

## Rule

Publish OpenAPI 3.1 contracts. Include request and response schemas, problem details, OAuth2 security requirements and stable operation IDs.[^policy]

[^policy]: Synthetic review record.
