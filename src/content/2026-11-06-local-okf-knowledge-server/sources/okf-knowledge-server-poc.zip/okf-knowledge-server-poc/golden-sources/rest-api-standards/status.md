---
type: "Standard"
title: "REST HTTP status codes"
description: "Return 201 Created with Location for successful creation, 204 for successful deletion without a body, 400 for malformed input, 401 for missing credentials, and 403 for insufficient privileges."
tags: ["rest api", "status"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/status", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
---

# REST HTTP status codes

## Rule

Return 201 Created with Location for successful creation, 204 for successful deletion without a body, 400 for malformed input, 401 for missing credentials, and 403 for insufficient privileges.[^policy]

[^policy]: Synthetic review record.
