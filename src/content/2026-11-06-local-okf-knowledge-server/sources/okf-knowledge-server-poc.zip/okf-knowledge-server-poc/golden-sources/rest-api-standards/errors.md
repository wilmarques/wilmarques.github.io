---
type: "Standard"
title: "REST API problem details"
description: "Return RFC 9457 application/problem+json with type, title, status, detail and instance."
tags: ["rest api", "errors"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/errors", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "api-errors"
relations: [{"type": "related_to", "target": "okf://java-standards/exceptions"}, {"type": "related_to", "target": "okf://java-standards/logging"}, {"type": "supersedes", "target": "okf://rest-api-standards/errors-envelope"}]
---

# REST API problem details

## Rule

Return RFC 9457 application/problem+json with type, title, status, detail and instance. Add a correlationId and structured field errors where needed. Never expose stack traces.[^policy]

[^policy]: Synthetic review record.
