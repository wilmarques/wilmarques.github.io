---
type: "Standard"
title: "REST URL design"
description: "Use lowercase plural noun collection paths and hyphenated segments."
tags: ["rest api", "urls"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/urls", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
---

# REST URL design

## Rule

Use lowercase plural noun collection paths and hyphenated segments. Keep resource identifiers opaque and avoid action verbs in URLs.[^policy]

[^policy]: Synthetic review record.
