---
type: "Standard"
title: "REST HTTP method semantics"
description: "GET is safe and idempotent."
tags: ["rest api", "methods"]
technology: "rest api"
status: "stable"
generated: {"by": "human:api-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/rest-api-standards/methods", "title": "Synthetic review record", "author": "human:api-council"}]
verified: [{"by": "human:api-council", "at": "2026-07-10T00:00:00Z"}]
---

# REST HTTP method semantics

## Rule

GET is safe and idempotent. POST creates a subordinate resource. PUT replaces a resource and is idempotent. PATCH partially updates it. DELETE is idempotent.[^policy]

[^policy]: Synthetic review record.
