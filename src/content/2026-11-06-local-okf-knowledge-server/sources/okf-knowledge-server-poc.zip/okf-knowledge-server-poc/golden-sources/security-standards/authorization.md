---
type: "Standard"
title: "Security authorization and scopes"
description: "Deny by default and require the operation scope, such as orders:write for creating orders."
tags: ["security", "authorization"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/authorization", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://security-standards/authentication"}, {"type": "related_to", "target": "okf://rest-api-standards/status"}]
---

# Security authorization and scopes

## Rule

Deny by default and require the operation scope, such as orders:write for creating orders. Check ownership for resource access. Distinguish 401 from 403.[^policy]

[^policy]: Synthetic review record.
