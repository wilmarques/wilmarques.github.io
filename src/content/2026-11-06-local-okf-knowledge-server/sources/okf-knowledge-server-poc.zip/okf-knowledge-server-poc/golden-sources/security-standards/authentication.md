---
type: "Standard"
title: "Security OAuth2 authentication"
description: "Use OAuth2/OIDC bearer access tokens for service APIs."
tags: ["security", "authentication"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/authentication", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "authentication"
relations: [{"type": "related_to", "target": "okf://security-standards/tokens"}, {"type": "supersedes", "target": "okf://security-standards/auth-basic"}, {"type": "related_to", "target": "okf://spring-boot-standards/security"}]
---

# Security OAuth2 authentication

## Rule

Use OAuth2/OIDC bearer access tokens for service APIs. Validate JWT signature, issuer, audience and expiry. Basic authentication is superseded.[^policy]

[^policy]: Synthetic review record.
