---
type: "Standard"
title: "Security secret management"
description: "Load secrets from the approved secret manager using workload identity."
tags: ["security", "secrets"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/secrets", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
---

# Security secret management

## Rule

Load secrets from the approved secret manager using workload identity. Keep secrets out of Git and application logs. Rotate credentials without rebuilding images.[^policy]

[^policy]: Synthetic review record.
