---
type: "Standard"
title: "Legacy Basic authentication"
description: "An old deployment guide allowed HTTP Basic authentication for internal REST endpoints."
tags: ["security", "auth-basic"]
technology: "security"
status: "deprecated"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/auth-basic", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "authentication"
relations: [{"type": "related_to", "target": "okf://security-standards/authentication"}]
---

# Legacy Basic authentication

## Rule

An old deployment guide allowed HTTP Basic authentication for internal REST endpoints.[^policy]

[^policy]: Synthetic review record.
