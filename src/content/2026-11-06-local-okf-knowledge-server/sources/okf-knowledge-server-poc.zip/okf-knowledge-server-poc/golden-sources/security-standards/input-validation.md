---
type: "Standard"
title: "Security input validation"
description: "Treat client input as untrusted."
tags: ["security", "input-validation"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/input-validation", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://spring-boot-standards/validation"}]
---

# Security input validation

## Rule

Treat client input as untrusted. Apply server-side allowlists and length bounds at ingress, and use parameterized queries for database operations.[^policy]

[^policy]: Synthetic review record.
