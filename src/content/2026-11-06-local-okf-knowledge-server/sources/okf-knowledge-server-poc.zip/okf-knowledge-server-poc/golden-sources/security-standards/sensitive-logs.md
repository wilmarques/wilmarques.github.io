---
type: "Standard"
title: "Security sensitive data logging"
description: "Never log bearer tokens, passwords or payment identifiers."
tags: ["security", "sensitive-logs"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/sensitive-logs", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "sensitive-logging"
relations: [{"type": "related_to", "target": "okf://java-standards/logging"}, {"type": "supersedes", "target": "okf://security-standards/log-mask"}]
---

# Security sensitive data logging

## Rule

Never log bearer tokens, passwords or payment identifiers. Use redaction for PII and retain only the correlation identifier for diagnosis.[^policy]

[^policy]: Synthetic review record.
