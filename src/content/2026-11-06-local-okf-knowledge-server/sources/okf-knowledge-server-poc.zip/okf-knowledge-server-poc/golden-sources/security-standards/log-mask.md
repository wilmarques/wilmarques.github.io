---
type: "Example"
title: "Security logging partial token example"
description: "An example displays the first token characters to diagnose failed authorization."
tags: ["security", "log-mask"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/log-mask", "title": "Synthetic review record", "author": "human:security-council"}]
policy_key: "sensitive-logging"
relations: [{"type": "related_to", "target": "okf://security-standards/sensitive-logs"}]
---

# Security logging partial token example

## Rule

An example displays the first token characters to diagnose failed authorization.[^policy]

[^policy]: Synthetic review record.
