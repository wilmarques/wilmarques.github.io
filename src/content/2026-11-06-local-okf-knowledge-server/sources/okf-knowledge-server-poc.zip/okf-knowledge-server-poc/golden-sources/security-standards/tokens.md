---
type: "Standard"
title: "Security access token handling"
description: "Accept access tokens only through the Authorization Bearer header."
tags: ["security", "tokens"]
technology: "security"
status: "stable"
generated: {"by": "human:security-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/security-standards/tokens", "title": "Synthetic review record", "author": "human:security-council"}]
verified: [{"by": "human:security-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://security-standards/authentication"}]
---

# Security access token handling

## Rule

Accept access tokens only through the Authorization Bearer header. Do not accept refresh tokens at resource servers. Apply a bounded clock skew and reject expired tokens.[^policy]

[^policy]: Synthetic review record.
