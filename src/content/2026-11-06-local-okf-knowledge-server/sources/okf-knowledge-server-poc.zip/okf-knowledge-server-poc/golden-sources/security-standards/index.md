---
okf_version: "0.2"
---

# security-standards

## Standards

- [Security OAuth2 authentication](authentication.md): Use OAuth2/OIDC bearer access tokens for service APIs.
- [Security authorization and scopes](authorization.md): Deny by default and require the operation scope, such as orders:write for creating orders.
- [Security secret management](secrets.md): Load secrets from the approved secret manager using workload identity.
- [Security input validation](input-validation.md): Treat client input as untrusted.
- [Security sensitive data logging](sensitive-logs.md): Never log bearer tokens, passwords or payment identifiers.
- [Security access token handling](tokens.md): Accept access tokens only through the Authorization Bearer header.
- [Legacy Basic authentication](auth-basic.md): An old deployment guide allowed HTTP Basic authentication for internal REST endpoints.
- [Security logging partial token example](log-mask.md): An example displays the first token characters to diagnose failed authorization.
