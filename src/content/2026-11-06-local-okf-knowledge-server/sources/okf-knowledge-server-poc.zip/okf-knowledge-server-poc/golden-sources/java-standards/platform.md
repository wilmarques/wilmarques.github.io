---
type: "Standard"
title: "Java 17 runtime baseline"
description: "Target Java 17 or later on an approved LTS release."
tags: ["java", "platform"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/platform", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
---

# Java 17 runtime baseline

## Rule

Target Java 17 or later on an approved LTS release. Set the compiler release flag to match the deployment JVM. Use records for immutable data carriers and keep preview features off.[^policy]

[^policy]: Synthetic review record.
