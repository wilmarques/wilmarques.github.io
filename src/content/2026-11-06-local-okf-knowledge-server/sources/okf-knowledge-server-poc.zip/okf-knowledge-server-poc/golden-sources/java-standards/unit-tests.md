---
type: "Standard"
title: "Java unit testing"
description: "Use JUnit 5 and AssertJ for behavior-focused unit tests."
tags: ["java", "unit-tests"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/unit-tests", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
---

# Java unit testing

## Rule

Use JUnit 5 and AssertJ for behavior-focused unit tests. Name tests for business outcomes and mock only external collaborators.[^policy]

[^policy]: Synthetic review record.
