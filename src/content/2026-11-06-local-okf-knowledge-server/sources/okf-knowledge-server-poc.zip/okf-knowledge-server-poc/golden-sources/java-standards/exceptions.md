---
type: "Standard"
title: "Java exception handling"
description: "Raise domain-specific unchecked exceptions for business failures, preserve the original cause when wrapping, and translate exceptions at the application boundary."
tags: ["java", "exceptions"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/exceptions", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "java-exceptions"
relations: [{"type": "related_to", "target": "okf://java-standards/logging"}, {"type": "related_to", "target": "okf://rest-api-standards/errors"}]
---

# Java exception handling

## Rule

Raise domain-specific unchecked exceptions for business failures, preserve the original cause when wrapping, and translate exceptions at the application boundary. Catch narrowly and never swallow exceptions.[^policy]

[^policy]: Synthetic review record.
