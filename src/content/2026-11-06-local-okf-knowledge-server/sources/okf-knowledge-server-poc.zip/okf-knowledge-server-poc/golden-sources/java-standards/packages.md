---
type: "Standard"
title: "Java package organization"
description: "Organize packages by business capability, then by layer inside the capability."
tags: ["java", "packages"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/packages", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
---

# Java package organization

## Rule

Organize packages by business capability, then by layer inside the capability. Keep implementation classes package-private when practical. Do not create a global util dumping ground.[^policy]

[^policy]: Synthetic review record.
