---
type: "Standard"
title: "Java structured logging"
description: "Use SLF4J parameterized structured logs with a correlation ID."
tags: ["java", "logging"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/logging", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://security-standards/sensitive-logs"}]
---

# Java structured logging

## Rule

Use SLF4J parameterized structured logs with a correlation ID. Log failures once at the boundary and never log secrets or raw tokens.[^policy]

[^policy]: Synthetic review record.
