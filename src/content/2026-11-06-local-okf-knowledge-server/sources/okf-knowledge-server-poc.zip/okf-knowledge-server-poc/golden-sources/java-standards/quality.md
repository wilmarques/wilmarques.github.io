---
type: "Standard"
title: "Java code quality"
description: "Enforce compiler warnings, static analysis and deterministic formatting in CI."
tags: ["java", "quality"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/quality", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
---

# Java code quality

## Rule

Enforce compiler warnings, static analysis and deterministic formatting in CI. Keep business logic small and expressive. Refactor duplication after tests demonstrate behavior.[^policy]

[^policy]: Synthetic review record.
