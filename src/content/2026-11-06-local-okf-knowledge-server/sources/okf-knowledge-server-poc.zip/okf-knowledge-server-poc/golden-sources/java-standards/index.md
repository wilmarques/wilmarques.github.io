---
okf_version: "0.2"
---

# java-standards

## Standards

- [Java 17 runtime baseline](platform.md): Target Java 17 or later on an approved LTS release.
- [Java package organization](packages.md): Organize packages by business capability, then by layer inside the capability.
- [Java exception handling](exceptions.md): Raise domain-specific unchecked exceptions for business failures, preserve the original cause when wrapping, and translate exceptions at the application boundary.
- [Java dependency injection](injection.md): Use constructor injection and final fields.
- [Java structured logging](logging.md): Use SLF4J parameterized structured logs with a correlation ID.
- [Java unit testing](unit-tests.md): Use JUnit 5 and AssertJ for behavior-focused unit tests.
- [Java code quality](quality.md): Enforce compiler warnings, static analysis and deterministic formatting in CI.
- [Java exception handling example](exception-example.md): A tutorial catches Exception for demonstration in a sample command-line client.
