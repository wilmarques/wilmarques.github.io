---
type: "Standard"
title: "Java dependency injection"
description: "Use constructor injection and final fields."
tags: ["java", "injection"]
technology: "java"
status: "stable"
generated: {"by": "human:java-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/java-standards/injection", "title": "Synthetic review record", "author": "human:java-council"}]
verified: [{"by": "human:java-council", "at": "2026-07-10T00:00:00Z"}]
---

# Java dependency injection

## Rule

Use constructor injection and final fields. Avoid static service locators and field injection. Depend on a port where the implementation crosses a boundary.[^policy]

[^policy]: Synthetic review record.
