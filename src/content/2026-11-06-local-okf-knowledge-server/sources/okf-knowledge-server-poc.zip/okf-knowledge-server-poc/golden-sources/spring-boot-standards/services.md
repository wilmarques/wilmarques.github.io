---
type: "Standard"
title: "Spring Boot service layer"
description: "Put business orchestration in a @Service with constructor-injected dependencies."
tags: ["spring boot", "services"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/services", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://java-standards/injection"}, {"type": "related_to", "target": "okf://spring-boot-standards/transactions"}]
---

# Spring Boot service layer

## Rule

Put business orchestration in a @Service with constructor-injected dependencies. Call repositories from services. Keep the controller focused on HTTP concerns.[^policy]

[^policy]: Synthetic review record.
