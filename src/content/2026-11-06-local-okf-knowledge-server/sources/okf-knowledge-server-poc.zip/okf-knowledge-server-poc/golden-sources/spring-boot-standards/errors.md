---
type: "Standard"
title: "Spring Boot exception advice"
description: "Centralize exception-to-HTTP mapping in @RestControllerAdvice."
tags: ["spring boot", "errors"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/errors", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://rest-api-standards/errors"}, {"type": "related_to", "target": "okf://java-standards/exceptions"}, {"type": "related_to", "target": "okf://java-standards/logging"}]
---

# Spring Boot exception advice

## Rule

Centralize exception-to-HTTP mapping in @RestControllerAdvice. Return the shared problem JSON shape and omit stack traces.[^policy]

[^policy]: Synthetic review record.
