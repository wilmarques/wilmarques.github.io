---
type: "Standard"
title: "Spring Boot web test patterns"
description: "Use @WebMvcTest and MockMvc for controller contracts including security failures."
tags: ["spring boot", "tests"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/tests", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://java-standards/unit-tests"}]
---

# Spring Boot web test patterns

## Rule

Use @WebMvcTest and MockMvc for controller contracts including security failures. Use @SpringBootTest for integration across persistence and application wiring.[^policy]

[^policy]: Synthetic review record.
