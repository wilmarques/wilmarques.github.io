---
type: "Standard"
title: "Spring Boot request and response DTOs"
description: "Use separate request and response DTO records for public APIs."
tags: ["spring boot", "dtos"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/dtos", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://java-standards/platform"}]
---

# Spring Boot request and response DTOs

## Rule

Use separate request and response DTO records for public APIs. Keep persistence entities off the wire. Map between transport records and domain objects in the service or a mapper.[^policy]

[^policy]: Synthetic review record.
