---
type: "Example"
title: "Spring Boot REST controller tutorial"
description: "A tutorial REST controller binds the persistence entity directly and returns a bare object."
tags: ["spring boot", "controller-example"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/controller-example", "title": "Synthetic review record", "author": "human:spring-council"}]
policy_key: "spring-controller"
relations: [{"type": "related_to", "target": "okf://spring-boot-standards/controllers"}]
---

# Spring Boot REST controller tutorial

## Rule

A tutorial REST controller binds the persistence entity directly and returns a bare object. It illustrates framework wiring only.[^policy]

[^policy]: Synthetic review record.
