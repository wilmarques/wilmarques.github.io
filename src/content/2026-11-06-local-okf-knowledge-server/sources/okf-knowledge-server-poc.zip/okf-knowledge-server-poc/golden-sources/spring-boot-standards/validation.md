---
type: "Standard"
title: "Spring Boot Bean Validation"
description: "Annotate request DTO fields with Jakarta Bean Validation constraints and annotate @RequestBody with @Valid."
tags: ["spring boot", "validation"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/validation", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
relations: [{"type": "related_to", "target": "okf://security-standards/input-validation"}]
---

# Spring Boot Bean Validation

## Rule

Annotate request DTO fields with Jakarta Bean Validation constraints and annotate @RequestBody with @Valid. Validate business invariants in the service.[^policy]

[^policy]: Synthetic review record.
