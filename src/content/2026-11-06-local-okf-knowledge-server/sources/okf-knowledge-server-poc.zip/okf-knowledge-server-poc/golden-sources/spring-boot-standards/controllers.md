---
type: "Standard"
title: "Spring Boot REST controller design"
description: "Use a thin @RestController with constructor injection, @Valid request DTOs and a service delegate."
tags: ["spring boot", "controllers"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/controllers", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
policy_key: "spring-controller"
relations: [{"type": "related_to", "target": "okf://spring-boot-standards/services"}, {"type": "related_to", "target": "okf://spring-boot-standards/dtos"}, {"type": "related_to", "target": "okf://spring-boot-standards/validation"}, {"type": "related_to", "target": "okf://spring-boot-standards/security"}, {"type": "related_to", "target": "okf://rest-api-standards/urls"}, {"type": "related_to", "target": "okf://rest-api-standards/status"}, {"type": "related_to", "target": "okf://security-standards/authorization"}]
---

# Spring Boot REST controller design

## Rule

Use a thin @RestController with constructor injection, @Valid request DTOs and a service delegate. Return 201 and Location when creating a resource. Require authorization through Spring Security.[^policy]

[^policy]: Synthetic review record.
