---
okf_version: "0.2"
---

# spring-boot-standards

## Standards

- [Spring Boot REST controller design](controllers.md): Use a thin @RestController with constructor injection, @Valid request DTOs and a service delegate.
- [Spring Boot service layer](services.md): Put business orchestration in a @Service with constructor-injected dependencies.
- [Spring Boot request and response DTOs](dtos.md): Use separate request and response DTO records for public APIs.
- [Spring Boot Bean Validation](validation.md): Annotate request DTO fields with Jakarta Bean Validation constraints and annotate @RequestBody with @Valid.
- [Spring Boot exception advice](errors.md): Centralize exception-to-HTTP mapping in @RestControllerAdvice.
- [Spring Boot transaction boundaries](transactions.md): Use @Transactional at the service boundary for a write use case.
- [Spring Boot Spring Security configuration](security.md): Configure an OAuth2 resource server SecurityFilterChain for JWT bearer access tokens.
- [Spring Boot web test patterns](tests.md): Use @WebMvcTest and MockMvc for controller contracts including security failures.
- [Spring Boot REST controller tutorial](controller-example.md): A tutorial REST controller binds the persistence entity directly and returns a bare object.
