---
type: "Standard"
title: "Spring Boot transaction boundaries"
description: "Use @Transactional at the service boundary for a write use case."
tags: ["spring boot", "transactions"]
technology: "spring boot"
status: "stable"
generated: {"by": "human:spring-council", "at": "2026-06-20T00:00:00Z"}
sources: [{"id": "policy", "resource": "https://example.invalid/decisions/spring-boot-standards/transactions", "title": "Synthetic review record", "author": "human:spring-council"}]
verified: [{"by": "human:spring-council", "at": "2026-07-10T00:00:00Z"}]
---

# Spring Boot transaction boundaries

## Rule

Use @Transactional at the service boundary for a write use case. Keep transactions short. Avoid remote calls inside the transaction and set readOnly for suitable queries.[^policy]

[^policy]: Synthetic review record.
