# Benchmark results

## Retrieval

The frozen [judgments](../tests/retrieval/judgments.tsv) contain 32 independent intents and two phrasings each. Categories are simple (10), cross-repository (8), relationship-aware (6), and conflict/lifecycle (8). Each run executed 64 searches over actual stdio MCP for each configuration. There were 192 search calls total, plus native neighbor calls for category C. Search latency excludes neighbor calls. The fixture contains 43 concepts in five bundles.

Native default uses `search_concepts` full detail, limit five, no policy filter. Native filtered adds stable, human-reviewed, type Standard, native fresh or unspecified freshness, and the optional freshness prior. The adapter uses `search_knowledge` with a limit of five. All variants omit bundle selection. [Per-query evidence](../results/benchmark.json) includes expected and actual results, raw returned summaries, citations, policy decisions and relationships. [CSV](../results/benchmark.csv) supports tabular review.

| Profile and query form | P@5 | R@5 | MRR | Top-1 | Cross-repo | Graph edges | Authority | Lifecycle explained | Full citations | Search p50 / p95 ms | Error rate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Native default / all | 0.463 | 0.751 | 0.865 | 0.531 | 0.688 | 1.000 | 0.000 | 0.000 | 0.000 | 1.09 / 2.45 | 0% |
| Native default / natural | 0.456 | 0.740 | 0.854 | 0.562 | 0.750 | 1.000 | 0.000 | 0.000 | 0.000 | 1.20 / 2.91 | 0% |
| Native default / keywords | 0.469 | 0.761 | 0.875 | 0.500 | 0.625 | 1.000 | 0.000 | 0.000 | 0.000 | 1.04 / 1.98 | 0% |
| Native filtered / all | 0.497 | 0.791 | 0.984 | 0.766 | 0.750 | 1.000 | 1.000 | 0.000 | 0.000 | 1.12 / 2.77 | 0% |
| Native filtered / natural | 0.487 | 0.777 | 0.969 | 0.781 | 0.750 | 1.000 | 1.000 | 0.000 | 0.000 | 1.21 / 3.44 | 0% |
| Native filtered / keywords | 0.506 | 0.804 | 1.000 | 0.750 | 0.750 | 1.000 | 1.000 | 0.000 | 0.000 | 0.97 / 1.76 | 0% |
| Adapter / all | 0.475 | 0.764 | 0.992 | 0.812 | 0.750 | 1.000 | 1.000 | 1.000 | 1.000 | 1.54 / 4.74 | 0% |
| Adapter / natural | 0.469 | 0.748 | 0.984 | 0.812 | 0.750 | 1.000 | 1.000 | 1.000 | 1.000 | 2.01 / 5.32 | 0% |
| Adapter / keywords | 0.481 | 0.780 | 1.000 | 0.812 | 0.750 | 1.000 | 1.000 | 1.000 | 1.000 | 1.29 / 3.33 | 0% |

- Precision@5 divides relevant returned hits by five, including when fewer than five are returned. Recall@5 divides by the full judged set. MRR is the reciprocal rank of the first relevant item in the first five; Top-1 is stricter and requires the primary judged concept at rank one.
- Cross-repo success requires at least one relevant Top-5 result from **every** expected bundle in category B. Relationship success requires every labeled directed edge in category C. Native edges are gathered through actual `get_neighbors` calls from retrieved seeds. The adapter emits relationships on its search response.
- Authority succeeds when the intended approved rule ranks first and every judged rejected policy is absent from the first five. Lifecycle exclusion is scored separately. An explanation additionally requires the rejected policy's state and freshness to be present in the decision. Native search does not expose a decision object.
- Local identity correctness compares bundle, concept and path to the Git tree. Full citation adds repository and immutable revision. Synthetic repositories use `fixture:` identifiers without fabricated public URLs. GitHub blob URLs follow the same convention in managed Git mode. Citation correctness measures all returned hits, independently of relevance.
- Error rate includes protocol failures and errors from search or native neighbor calls used by the benchmark. Negative security tests intentionally making invalid calls are scored separately.

The frozen judgments have a fixed-denominator Precision@5 ceiling of **0.65**. Some simple and conflict questions legitimately have one to three relevant concepts. A perfect five-result ranker would still miss the 0.80 gate. The original target remains unchanged and scores are reported with the original denominator. The paired forms share the same expected sets, so they are not independent observations. There is no unseen corporate corpus, multilingual corpus, formal inter-rater assessment or separate blind ranking holdout in this POC.

Natural-language recall was lower than keyword recall in all three profiles. The adapter missed cross-repo B01 and B06 in natural form. For B01, all five returned concepts came from Spring Boot, even though the judged set also requires REST, Java and Security. In B06, the query about controller security testing and domain testing again overconcentrated on Spring Boot. Global search works, but high ranking of single-technology hits leaves gaps for compound work. The 100% relationship result pertains to the explicit fixture graph and the designated seed procedure.

## Scale and resource use

Debian GNU/Linux 13, Linux 6.18.57 x86-64, AMD EPYC 9V74, 9 logical CPUs available to Node, 9.73 GiB memory reported by the OS, Node 24.22.1. Each mode/size uses five generated bundles and three new child processes. Each process has a timed first search, five warmups, 30 serial measured queries with every third broad, and five batches of eight concurrently dispatched calls. Native graph timings use 15 subgraph traversals per process. Time uses monotonic wall clock. Measurements include stdio serialization, parser and tool overhead, excluding model inference.

| Concepts | Profile | Index load p50 | MCP startup p50 | Cold query p50 | Warm p50 / p95 | Graph p95 | Batch of 8 p95 | RSS MiB | Child CPU ms | Edit + restart |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 100 | Native default | 37.24 | 279.22 | 31.80 | 1.14 / 2.36 | 1.52 | 7.78 | 100.3 | 200 | 322.38 |
| 100 | Adapter | 35.08 | 309.75 | 29.00 | 1.67 / 3.04 | — | 7.11 | 100.7 | 150 | 329.51 |
| 1,000 | Native default | 124.29 | 355.73 | 69.26 | 3.48 / 4.66 | 2.34 | 24.10 | 141.1 | 410 | 380.47 |
| 1,000 | Adapter | 133.77 | 405.14 | 68.78 | 3.11 / 4.73 | — | 63.38 | 147.9 | 370 | 504.45 |
| 5,000 | Native default | 435.76 | 665.43 | 269.25 | 14.99 / 24.14 | 4.31 | 166.42 | 504.9 | 2040 | 856.25 |
| 5,000 | Adapter | 441.97 | 737.95 | 242.91 | 11.20 / 16.70 | — | 94.71 | 472.3 | 1510 | 932.74 |
| 10,000 | Native default | 736.86 | 1046.35 | 464.41 | 30.90 / 53.07 | 5.48 | 306.92 | 677.1 | 3650 | 1383.64 |
| 10,000 | Adapter | 728.59 | 1021.97 | 463.65 | 19.47 / 37.50 | — | 212.69 | 508.4 | 2660 | 1481.34 |

Index load is timed in separate fresh Node processes after imports. It includes native parsing and graph assembly, plus adapter validation and policy-map construction where applicable. Startup is spawn through successful MCP initialization, including initial OKF parse and graph load. Cold query exposes lazy lexical indexing and other first-query overhead. RSS is the maximum end-of-workload sample among the three children. CPU is median child process CPU milliseconds for the post-startup measurement workload, derived from Linux `/proc` counters. The native server queues tool handlers internally. Concurrent batch latency measures completion of the whole eight-call batch. The adapter attaches related edges to search and has no separate graph call. Restart after edit is time to start a fresh server and retrieve an edited marker, excluding Git fetch. Separately, the integration suite measures Git fetch plus validation and publication for the local synthetic five-repo update. See [scale samples](../results/scale.json) and [sync test evidence](../results/test-results.json).
