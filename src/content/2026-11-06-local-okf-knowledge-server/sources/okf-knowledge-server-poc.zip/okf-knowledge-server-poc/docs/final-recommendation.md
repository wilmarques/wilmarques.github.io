# Architecture decision | Local OKF Knowledge Server

**Decision date** 6 November 2026  
**Scope** Corporate engineering standards in GitHub OKF Golden Sources  
**Decision** **NO-GO for production with upstream alone. CONDITIONAL GO for a synthetic or explicitly authorized adapter pilot.**

## Executive summary

`@mfdaves/okf-mcp` can serve as the indexing and graph engine for a local, multi-repository Knowledge Server without dedicated infrastructure. One stdio process searched 43 OKF 0.2 concepts in five independent Git repositories. It retrieved typed relationships across bundles, and could also load public OKF directly from GitHub without a clone. Its default ranked output does not reliably select corporate authority or carry a local Git revision for every citation.

The adapter adds approved reviewer checks, explicit conflict handling, commit-backed citations, and last-known-good Git snapshots. It selected the expected authority in 16 of 16 conflict and lifecycle runs, attributed every returned result to the correct Git commit and file, and searched 1,000 concepts comfortably below the 500 ms p95 gate. Native filters also selected the expected authority in all 16 runs, with better recall than the adapter. The adapter's reason to exist is governance, citations, and a simpler agent-facing contract.

The adapter covered every expected repository in 12 of 16 multi-repository runs, below the 85% gate. Its Precision@5 was 0.475 against the 0.80 target. The fixed-denominator benchmark has a mathematical ceiling of 0.65 on the frozen judgments, so it cannot demonstrate the required precision on this question set. Neither this limitation nor the improved authority score resolves the observed coverage gap. The Codex agent trial was blocked before any tool call, and private GitHub authentication remains unverified.

## Implementation and version

- Tested upstream package `@mfdaves/okf-mcp@0.12.0-rc.1`, npm `next`, at Git commit `d10a05528289cb4a3440e7ea3c4b567d351a44d6`. The registry Git head and integrity were recorded. The upstream checkout's suite recorded 451 passed, two skipped or todo, and zero failed out of 453. The stable npm `latest` and latest GitHub release was 0.9.1, commit `66676afd2d28a0c35a62285d3c50d043f551fde8`. Stable passed a smaller MCP smoke test. Git tags also showed the prior RCs 0.11.0-rc.1 and 0.11.0-rc.2. [Upstream](https://github.com/mfdaves/okf-mcp/tree/d10a05528289cb4a3440e7ea3c4b567d351a44d6)
- Checked against GoogleCloudPlatform OKF 0.2 at commit `ad30107c31c06aec8a7d5636e0d1058118604e6f`. The native server parsed the versioned bundles and most core metadata. It warned on a valid offset-bearing `stale_after` datetime because this parser expects a calendar date. The adapter applies its own offset-aware date check. [Pinned specification](https://github.com/GoogleCloudPlatform/open-knowledge-format/blob/ad30107c31c06aec8a7d5636e0d1058118604e6f/SPEC.md)
- The main reproduction preserves the RC package but overrides the MCP server SDK, YAML parser and Zod to patched releases, with the official MCP client updated to the same SDK generation. The stock dependency audit flagged four packages and the hardened lockfile audit reported zero at test time. The workspace preserves both dependency baselines.
- Git sync fetches into managed shallow clones, verifies materialized bytes against Git blobs, validates the federated project, then publishes a generation. Codex launches the adapter over stdio. It reuses upstream parsing, BM25+ and graph relations, and exposes `search_knowledge` and `read_knowledge`. All data used for quality and scale tests was synthetic. No external embedding service was used.

## Results against the original gates

| Gate | Upstream default | POC adapter | Evidence |
|---|---|---|---|
| Local execution, no dedicated backend | PASS | PASS | Local stdio, in-memory indexing and offline retrieval with the network tripwire. |
| Real MCP calls | PASS | PASS | Official TypeScript SDK over real subprocess stdio, protocol 2025-11-25. |
| Five searchable bundles | PASS | PASS | 43 concepts across Java, Spring Boot, REST API, Security and Angular. |
| Autonomous discovery, no repository names | PARTIAL | PARTIAL | Real global queries needed no bundle names. Codex agent behavior **NOT TESTED**. |
| Cross-repository retrieval ≥85% | FAIL | FAIL | Default 11/16, adapter 12/16. Native filters also 12/16. |
| Precision@5 ≥0.80 | FAIL | FAIL | Default 0.463, adapter 0.475. Frozen dataset ceiling 0.65. |
| MRR ≥0.80 | PASS | PASS | Default 0.865, adapter 0.992. MRR is based on the first relevant hit. |
| Source attribution ≥95% | PARTIAL | PASS | Default identified bundle, concept and file correctly, with no local repo/commit citation. Adapter exact full citations 100%. |
| Authority handling ≥90% | FAIL | PASS | Default 0/16, adapter 16/16. Native filters also selected 16/16, with no explanation of rejected policy variants. |
| At 1,000 concepts, p95 search <500 ms | PASS | PASS | Warm stdio p95 was 4.66 ms native and 4.73 ms adapter. See `results/scale.json` for exact values. |
| Read-only and no exposed secrets | PASS | PASS | Mutation tool calls denied, content hashes unchanged, no secrets used or included. Corporate credential, endpoint and model boundaries still require a pilot. |
| Reproducible setup and tests | PASS | PASS | Lockfile, bootstrap, synthetic Git fixtures, MCP tests, judged queries and recorded evidence included. Executed on Linux, including a fresh ZIP extraction into a path containing spaces. |
| Codex end-to-end endpoint | NOT TESTED | NOT TESTED | CLI accepted the stdio definition through one-off configuration. Execution exited before any model or tool event. |
| Authorized private GitHub access | NOT TESTED | NOT TESTED | Local Git and public HTTPS executed. No private repository or credentials were used. |

## Operational findings

Public no-clone loading succeeded from two GitHub repositories with an empty working directory. Startup was about 21 seconds for five searchable concepts. A missing public source blocked startup even with a valid local bundle configured. The loader's fixed unauthenticated requests, bounds and startup availability dependency make it useful for inspecting public sources. The managed Git path is the recommended baseline for developers.

Native read-only search does not refresh on file changes. A missing or deleted locator can force a native full rebuild, while an edited existing file continued to return cached content in the test. The adapter uses explicit sync and reconnect. Add, change, remove, deprecate, verify and cross-repository link updates were exercised. Invalid or unavailable sources preserved the last successful generation. Old generations consume disk and need retention management.

Scale tests reached 10,000 concepts with three fresh processes per size and mode. At 10,000 concepts, warm p95 was 53.07 ms native and 37.50 ms adapter. Peak or sampled RSS varied substantially at 5,000 and 10,000 concepts, reaching several hundred MiB. Verify actual corpus sizes, broad queries, cold startup and parallel workloads on managed developer laptops before setting operational targets.

## Alternatives

The weighted use-case scores were 76/100 for the adapter, 73 for native with filters, 69 for upstream default, 60 for an unbuilt custom OKF server, 50 for GitNexus, 49 for Graphify, and 48 for Sourcebot. GitNexus, Graphify and Sourcebot were assessed from official project documentation. They received no experimental retrieval scores. GitNexus and Graphify focus on code graphs and cross-repo navigation. Sourcebot offers cross-repo search through a running deployment. The OKF-specific lifecycle and provenance in this POC require dedicated handling in those products. See `docs/gap-analysis.md` in the workspace for the full rubric and sources.

## Conditions for progressing beyond a pilot

1. Use a separate blinded evaluation with enough judged relevant items per query to measure the unchanged 0.80 Precision@5 threshold, plus a predeclared metric for sparse-answer cases. Improve compound retrieval and verify the original 85% cross-repository gate on held-out questions.
2. Complete a real Codex run on the supplied Spring Boot trial. Verify autonomous calls, exact citations, generated code, and passing endpoint tests. Repeat with hostile document content to test model behavior.
3. Run a least-privilege private GitHub pilot using approved Git credentials and an approved model/data path. Verify macOS and Windows setups in addition to Linux.
4. Make policy keys, source IDs and review roles centrally governed and auditable. Introduce a signed snapshot manifest, disk retention, rollback, and an enforced version/patch policy. Bound untrusted corpus and tool payload sizes before broader use.
5. Validate the next supported upstream version and the timestamp conformance fix. Keep the adapter dependent on the narrow upstream interfaces already exercised by the contract tests.

Detailed implementation, executable scripts, raw results and evidence are included in the workspace ZIP. Start with `README.md`, then see `docs/benchmark-results.md` for metric definitions and `docs/security-assessment.md` for the trust boundaries.
