# Architecture

The developer runs Git sync on demand. The sync CLI uses the developer's existing Git authentication, fetches one configured ref per repository, resolves each to a commit, verifies the checkout bytes against Git blobs, and validates a federated OKF project. Only after the whole generation validates does it replace the active snapshot pointer. Codex starts the server as a child process and exchanges MCP messages over stdio.

```mermaid
flowchart TD
    R["Approved GitHub repositories"] --> S["On-demand Git sync"]
    S --> V["Validate one pinned snapshot"]
    V --> P["Publish active generation"]
    P --> M["Local read-only MCP process"]
    C["Codex or MCP SDK client"] <-->|"stdio"| M
    M --> I["OKF index, search, and graph"]
    M --> A["Authority policy and citations"]
```

## Mode A | managed local bundles

The upstream package parses Markdown and YAML and constructs an in-memory index for all configured bundles. MiniSearch supplies BM25+ lexical ranking. The native graph projects links, extension relations, and path-valued semantic fields. Cross-repository relationships use canonical `okf://bundle/concept` locators in the upstream `relations` extension. Relative Markdown links inside a single bundle remain portable OKF. Absolute source URLs in OKF describe provenance. The wrapper's citation is a separate locator for the precise indexed file and commit.

The runnable fixture project is [okf.project.yaml](../okf.project.yaml). Upstream project bundle paths must stay under the configuration directory. The sync script generates a second project under `.runtime/snapshot-*/`, alongside its own cloned checkouts. The checked-in `config/okf.project.yaml` is a template. Fixture origins are separate Git repositories with deterministic commit metadata, using separate Java, Spring Boot, REST API, Security and Angular OKF roots.

## Mode B | native public GitHub loader

The native CLI loads configured public tree subdirectories at startup. It resolves a mutable ref to a commit, enumerates GitHub contents, and downloads Markdown and referenced inert assets. The POC uses pinned commit URLs. Content lives in process memory. The load uses public GitHub API and raw downloads, with no private Git credential integration. See [remote measurements](../results/evidence/remote.json).

## Adapter boundary

| Layer | Responsibility |
|---|---|
| Upstream | Parse OKF, validate bundle structure and references, index concepts, run BM25+, build typed graph edges. |
| `src/knowledge.mjs` | Collect global candidates, use coverage-weighted lexical ranking, apply authority rules, surface typed relations, produce bounded excerpts and provenance. |
| `src/server.mjs` | Expose only `search_knowledge` and `read_knowledge`. Tool arguments select a query or exact indexed URI. |
| `scripts/sync.mjs` | Stage Git snapshots, verify blob bytes, validate all bundles, and publish one generation. |
| GitHub governance | Decide who may change standards and resolve disagreements in Git. |

Authority requires a stable `Standard`, a locally allowed reviewer with an eligible verification timestamp, and a current or unspecified freshness date. Verification cannot predate a supplied content generation timestamp. The adapter handles the specification's offset-bearing `stale_after` timestamps directly. A shared `policy_key` makes a disagreement explicit. One eligible standard wins, two eligible peers produce an ambiguous decision, and a group with none produces no recommendation. The policy neither infers semantic contradiction nor treats a newer date alone as a tie-breaker. Shared keys, approved reviewer identities, and repository selection are organization-specific and require governance. The adapter uses a candidate cap of 75 lexical hits and returns up to eight results. Relationships are evidence adjacent to returned results and do not manufacture text or populate the ranked list. It returns compact supporting source records and immutable GitHub blob URLs for managed real repositories. For fixture repos the commit and file identify the synthetic source and no public URL is invented.

## Refresh and failure model

Every successful sync is a new immutable-by-convention snapshot. An open server continues to serve its original snapshot. Restart Codex or reconnect MCP to adopt a new one. Failure before publish leaves the prior pointer intact. Fetches happen sequentially and are individually pinned, so a cross-repository release that must be atomic should distribute a manifest of commit SHAs as one approved release. Old snapshots are retained to avoid invalidating open sessions. Operators can remove unused generations after all sessions using them have stopped.
