# Installation and operation

## Local synthetic setup

Tested on Debian GNU/Linux 13 x64, Node 24.22.1, npm 11.9.0 and Git 2.52.0. Node 22+ and Git are required. The scripts avoid Bash-specific behavior at runtime. macOS and Windows are intended targets, and remain untested in this POC.

```sh
node scripts/bootstrap.mjs
npm test
npm run benchmark
npm run scale
```

Equivalent setup is `npm ci --ignore-scripts --no-fund` followed by `npm run setup`. After setup, Mode A works offline. Use `npm run serve` only as a stdio server with an MCP client. Waiting for input is normal. The upstream-only fixture endpoint is:

```sh
node node_modules/@mfdaves/okf-mcp/bin/okf-mcp.js --project okf.project.yaml mcp
```

When configuring a client, use absolute paths for the Node executable, project, and server entry point. Local bundle paths *inside* the project file are relative to that file. To avoid copying over developer credentials or an existing source manifest, bootstrap makes synthetic origins under the ignored `.runtime/` directory. Running `npm run setup` switches the active pointer to fixtures. Use a separate installation directory for corporate sources. 

## Use GitHub Golden Sources

1. Copy [sources.example.json](../config/sources.example.json) to a private local file. Set a stable lowercase bundle `id`, a credential-free GitHub HTTPS or SSH URL, a branch/tag/full commit as `ref`, the bundle directory as `root` (or `.`), and an approved `reviewers` list. Cross-bundle locators must use the configured IDs.
2. Authenticate with your organization's approved Git Credential Manager, GitHub CLI credential helper, or SSH agent. Scope repository access to read only. Confirm each Git remote works before invoking sync. For GitHub Enterprise Server or a mirror, the URL allowlist needs an explicit reviewed change.
3. Run `npm run sync -- /absolute/path/to/sources.json`. Windows paths containing spaces should be quoted.
4. Start Codex with the MCP entry registered, or restart the running client after a refresh.

The sync code uses standard `git fetch` with configured credentials, a shallow detached checkout, and no submodules or hooks. It verifies the materialized bytes against the Git blob identities. Git URL rewrites and the credential helper are developer-controlled and part of the trusted setup. A credential prompt should be completed before sync. Fetch failure reports the affected bundle ID, and discards Git stderr to avoid leaking credentials. For diagnosis, run Git separately in a trusted terminal. Source changes are visible after a successful sync and restart. The script serializes fetches in one invocation. When two invocations overlap, the last completed publication wins. Retain old generations for active sessions and use a single invocation at a time.

## Public no-clone test

```sh
npm run remote
npm run git:public
```

The remote command launches the native server with two GitHub tree URLs pinned to commits and an isolated working directory. Successful startup needs `api.github.com` and the download host returned by GitHub, normally `raw.githubusercontent.com`. It forwards proxy and certificate variables only. For a direct run:

```sh
node node_modules/@mfdaves/okf-mcp/bin/okf-mcp.js \
  --remote-bundle okf-runtime=https://github.com/mfdaves/okf-mcp/tree/d10a05528289cb4a3440e7ea3c4b567d351a44d6/okf/okf-mcp/runtime mcp
```

Use subdirectory URLs with a single ref segment or a full commit SHA. The upstream loader uses sequential API and raw requests, has no persistent clone/cache or credential callback in its CLI, and enforces file and byte bounds. It cannot refresh an active configured remote on a timer. A startup fetch failure blocks even a mixed local/remote session. Local Git snapshots give offline operation and a recoverable last-known-good generation. The Git smoke command fetches a pinned full public OKF bundle over HTTPS, checks its revision, and verifies that a strict validation failure for a narrow subdirectory preserves the prior snapshot.

## Package and pinning

Production candidate setup would package a scoped internal npm CLI with bundled entry points, keep the lock and overrides, include an install-time smoke test, and maintain a signed configuration manifest. This workspace is private and does not publish a package. Install-time network access is limited to dependencies unless Git sync is invoked. See [dependency evidence](../results/evidence/dependency-tree.txt).

Stock upstream reproduction is separate. The published package Git head and integrity are in the evidence directory. To run the upstream suite, check out the recorded commit, run `npm ci --ignore-scripts`, then `npm test`. The POC default retains the same upstream package version while using patched dependency overrides. The saved [stock dependency manifests](../results/evidence/stock-dependencies/) describe the unmodified RC dependency baseline. Run their reproduction only on synthetic data.
