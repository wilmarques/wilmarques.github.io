# Codex MCP integration

## Registration

Use Codex's supported local stdio registration. The workspace supplies `npm run codex:register`, which calls the equivalent of:

```sh
codex mcp add corporate_knowledge -- /absolute/path/to/node /absolute/path/to/okf-knowledge-server-poc/src/server.mjs
codex mcp list
```

The adapter resolves its active snapshot at each process start. For an explicitly selected fixture or policy project, the equivalent TOML is:

```toml
[mcp_servers.corporate_knowledge]
command = "/absolute/path/to/node"
args = ["/absolute/path/to/okf-knowledge-server-poc/src/server.mjs"]
required = true
enabled_tools = ["search_knowledge", "read_knowledge"]
startup_timeout_sec = 20
tool_timeout_sec = 20
```

Use TOML-escaped Windows paths or forward slashes. Trusted project configuration can scope the setting. Sources must be available to the machine hosting the MCP subprocess. The tools include descriptions for discovery, and any repository-level agent instruction should say when standards lookup is required without embedding the standards or bundle names. [Official Codex MCP configuration](https://developers.openai.com/codex/mcp)

## End-to-end trial

Run `npm run setup` and then `npm run codex:trial` in an environment where Codex can start and use an approved model. The command creates an isolated copy of [the Spring Boot starter](../tests/codex-app/) and uses the documented config overrides. The initial prompt asks Codex to implement a secured create-order endpoint under corporate standards and cite the Golden Sources. It supplies no standards, tool names, or bundle names. It records JSONL, stderr, exit status, and completed MCP calls in a fresh directory under `.runtime/`. The starter contains Java and Maven configuration, without an endpoint implementation.

Review the log and resulting patch. Count tool calls and verify search has no oracle repo input. Check which citations are returned against `sources.json` and Git. In the generated application, run `mvn test` and inspect actual behavior and tests for 201/Location, request validation, separate DTOs, service boundary, proper JWT validation, deny-by-default with the required order scope, and documented error handling. Compare against the precise rules returned, and record any gaps between those rules and the produced code.

## Observed result

Codex CLI 0.167.0-alpha.4 reported a ChatGPT login. A one-off configuration showed the enabled stdio entry in the CLI list. The trial exited 1 before any JSONL or MCP events due to a read-only filesystem during in-process app-server initialization. The initial attempt also reported a SQLite state path failure. Setting supported `sqlite_home` and `log_dir` to an isolated writable directory eliminated the SQLite warning but did not fix the app-server failure. No generated endpoint or Maven validation is available from these trials.

A real official TypeScript MCP SDK client negotiated protocol 2025-11-25, discovered both catalogs, called the server subprocesses over stdio, parsed structured or JSON text payloads, and verified multi-bundle, citations, relationship and read-only behavior. This verifies the server-side protocol path. Codex discovery, autonomous tool invocation, and standards-compliant code generation remain **NOT TESTED**. See [test evidence](../results/test-results.json) and [Codex trial receipts](../results/evidence/README.md).
