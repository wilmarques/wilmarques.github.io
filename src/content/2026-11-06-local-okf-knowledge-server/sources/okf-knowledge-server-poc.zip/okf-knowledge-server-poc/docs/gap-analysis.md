# Capability evidence and alternatives

## Native evidence matrix

Source paths refer to [upstream commit d10a055](https://github.com/mfdaves/okf-mcp/tree/d10a05528289cb4a3440e7ea3c4b567d351a44d6). Protocol and test observations are in [test-results.json](../results/test-results.json) and [remote.json](../results/evidence/remote.json).

| Capability | Classification | Source and execution evidence |
|---|---|---|
| OKF 0.2 reading | Native support, partial conformance | `src/v02.js`, `test/v02-integration.test.js`. Five declarations recognized, and status, generation, verification, sources and graph worked. Valid offset-bearing `stale_after` is rejected as an advisory by the native date-only parser. |
| `okf.project.yaml` and local federation | Supported with configuration | `src/project.js`, `src/indexer/build.js`. Five independent checkouts load under one project, with validated bundle IDs and paths. |
| Global and bundle-scoped search | Native support | `src/mcp/tools/search.js`, `src/search/query.js`. Global query omitted bundle and returned several sources. Scoped request returned Java only. |
| BM25+ and ranking | Native support | `src/search-index.js`, `src/search/query.js`, `test/search*.test.js`. MiniSearch, lexical ranking, English stemming and confidence. Benchmark scores are query-relative. Natural-language queries work as text queries with mixed quality. |
| Read-only stdio | Native support | `src/mcp/server.js`, `src/mcp/registry.js`, `test/mcp-sdk.test.js`. Negotiated MCP 2025-11-25. Runtime load and write tools absent unless opted in. |
| `list_bundles` | Native support | `src/mcp/tools/catalog.js`. Lists local bundle identity and counts. Public remote listings add GitHub URL, ref and commit revision. |
| `get_concept` | Native support | `src/mcp/tools/catalog.js`. Full frontmatter, Markdown, links and normalized signals; unknown/deleted local locator triggers a rebuild. |
| `get_graph`, `get_neighbors`, `get_subgraph`, `find_paths` | Native support | `src/mcp/tools/graph.js`, `src/graph.js`, `test/directory-links.test.js`. Verified cross-bundle neighbors, subgraph, and directed path. Typed relations are an upstream extension beyond bundle-relative OKF links. |
| `get_provenance` | Native support | `src/mcp/tools/provenance.js`, `src/computation.js`. Verified normalized source leaves with inert URLs. Provenance of a claim differs from the Git commit that supplies the current concept file. |
| `validate_bundle` | Native support | `src/mcp/tools/catalog.js`, `src/indexer/build.js`, `test/conformance.test.js`. Separate conformance and project validity. Invalid concepts were excluded from normal search while healthy concepts remained. |
| Lifecycle and trust filters | Supported with configuration | `src/search/query.js`, `src/v02.js`. Callers can filter type, status, trust, freshness and verification or enable a prior. Filtered benchmark passed fixture selection, with no structured disagreement report. |
| Authority and current-vs-obsolete policy decision | Requires extension | Frontmatter can declare type, `supersedes` and trust, but default search does not enforce policy. The adapter adds a reviewer allowlist, explicit policy grouping, abstention and evidence for retired variants. |
| Local repo, concept, file and commit citation | Requires extension | Native full search has bundle/path/concept. Local project supplies roots without automatically binding every concept to repository and HEAD. The separate pinned `sources[].git`/mapping tool is for declared inputs. Adapter supplies Git metadata from the managed snapshot. |
| Public GitHub without a clone | Supported with configuration | `src/remote.js`, `src/mcp/server.js`, `test/okf-mcp.test.js`. Public pinned tree subdirectories worked, 404 prevented startup. |
| Native private GitHub URL loading | Unsupported | `src/remote.js` passes fixed unauthenticated headers, with no standard Git helper/SSH handoff. The library permits an injected fetch function. That would be a custom integration. |
| Private GitHub using managed local clones | Not verified | Standard Git helper and SSH path is present in the design and sync script. Synthetic Git sync and one public GitHub HTTPS fetch were executed. An authorized private repository and credential flow were unavailable. |
| Incremental indexing | Native support in library and write paths | `src/indexer/update.js`, `src/mcp/server.js`, `test/index-update*.test.js`. Incremental updates and refresh helpers are not a complete read-only Git synchronization feature. |
| Read-only automatic refresh/sync | Requires extension | Normal search and reads of existing files use the snapshot. A missing or deleted locator through native `get_concept` can force a full rebuild. Managed refresh uses the separate sync command plus reconnect/restart. |
| MCP use by Codex agent | Not verified | CLI accepted local configuration. Model-driven invocation could not start. Actual SDK fallback passed. |
| Embeddings and hybrid retrieval | Supported with configuration, not verified by this POC | Upstream source and own suite cover optional hybrid search. No embedding API or vector store was used for POC retrieval or performance. |

## Weighted comparison

Scores run from 0 to 5. A 0 means absent or incompatible with the requirement, 1 indirect, 2 substantial adaptation, 3 usable with material gaps, 4 good with smaller gaps, and 5 a strong fit. Total is the weighted sum divided by 5. Scores express fit for OKF policy discovery. Experimental scores are based on this POC, documentation scores describe the advertised design, and the custom entry is an architectural estimate. No alternative was benchmarked on the fixture.

| Criterion | Weight | Upstream default | Upstream + filters | POC adapter | GitNexus | Graphify | Sourcebot | Custom OKF MCP |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Multi-repository knowledge retrieval | 25% | 4 | 4 | 4 | 3 | 3 | 5 | 3 |
| Corporate standards answer quality | 25% | 2 | 3 | 3 | 1 | 2 | 2 | 2 |
| Zero-infrastructure operation | 15% | 5 | 5 | 5 | 5 | 4 | 0 | 5 |
| MCP and Codex interoperability | 10% | 4 | 4 | 4 | 4 | 3 | 3 | 3 |
| OKF-native capabilities | 10% | 4 | 4 | 4 | 0 | 0 | 0 | 4 |
| Security and maintainability | 10% | 2 | 2 | 3 | 2 | 2 | 3 | 2 |
| Developer experience | 5% | 4 | 3 | 4 | 3 | 2 | 1 | 2 |
| **Total / 100** | **100%** | **69** | **73** | **76** | **50** | **49** | **48** | **60** |
| Evidence | | Experiment | Experiment | Experiment | Docs | Docs | Docs | Design |

- **GitNexus** documents a local code index, Codex setup, repository allowlists, and group tools. Multiple indexes are different from default global policy search. Typical calls need a selected repository or configured group/default, and the documentation distinguishes enterprise unified graphs. Its current public license is noncommercial, so validate corporate usage rights. No OKF trust or lifecycle support was found in the reviewed docs. [Repository](https://github.com/abhigyanpatwari/GitNexus) · [MCP reference](https://github.com/abhigyanpatwari/GitNexus/blob/main/docs/mcp-reference.md)
- **Graphify** documents local code graph generation, a separate configured semantic pass for docs/media, and merging multiple graph artifacts with origin metadata. It offers MCP and Codex integration surfaces, including a separate hosted offering. An OKF-native parser, approval model, and lifecycle ranking were not established. [Project](https://github.com/Graphify-Labs/graphify) · [Cross-repo merge](https://github.com/Graphify-Labs/graphify/blob/v8/graphify/skills/codex/references/github-and-merge.md)
- **Sourcebot** documents global repository code search, MCP and deployment using Docker Compose or Kubernetes. A client can search multiple repos without local clones. It depends on a running Sourcebot instance and the documented deployment path. Its file and code context could locate Markdown, while OKF authority and graph handling remain unestablished. [Overview](https://docs.sourcebot.dev/docs/overview) · [Deployment](https://docs.sourcebot.dev/docs/deployment/deploy-sourcebot) · [MCP](https://docs.sourcebot.dev/docs/features/mcp-server)
- **Custom lightweight OKF MCP** can own the parser profile, retrieval and governance from the start, with Node, Markdown/YAML parsing, in-memory text ranking and Git snapshots. This is an unbuilt alternative. It would own conformance, graph algorithms, security, compatibility and benchmarking as ongoing product work. The adapter already covers the strongest differentiation with less replacement code.

## Production gaps

The adapter is small enough to maintain independently of the upstream codebase, but depends on upstream index records and semantic behavior as well as documented library exports. Pin with a contract test before upgrades. Sync is deliberately full and is a separate operational command. The critical remaining work is an independent quality benchmark for compound queries, an agent end-to-end run, a private Git pilot, governance for reviewer identity and policy keys, and snapshot lifecycle controls. The known `stale_after` discrepancy should be fixed upstream or guarded by a conformance regression.
